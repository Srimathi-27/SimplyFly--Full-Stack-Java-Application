package com.simplyfly.airticketbooking;

import com.simplyfly.airticketbooking.dto.AddFlightRequest;
import com.simplyfly.airticketbooking.dto.FlightResponse;
import com.simplyfly.airticketbooking.dto.FlightSearchRequest;
import com.simplyfly.airticketbooking.entity.*;
import com.simplyfly.airticketbooking.enums.Role;
import com.simplyfly.airticketbooking.enums.SeatClass;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.*;
import com.simplyfly.airticketbooking.service.impl.FlightServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FlightServiceImplTest {

    @Mock private FlightRepository flightRepository;
    @Mock private RouteRepository routeRepository;
    @Mock private UserRepository userRepository;
    @Mock private SeatRepository seatRepository;

    @InjectMocks private FlightServiceImpl flightService;

    @Mock private Authentication authentication;

    private User user;
    private Route route;
    private Flight flight;

    @BeforeEach
    void setup() {
        user = new User();
        user.setEmail("admin@example.com");
        user.setRole(Role.ADMIN);

        route = new Route();
        route.setId(1L);
        route.setOrigin("Chennai");
        route.setDestination("Delhi");

        flight = new Flight();
        flight.setId(1L);
        flight.setFlightName("Air India");
        flight.setFlightNumber("AI101");
        flight.setRoute(route);
        flight.setTotalSeats(60);
        flight.setFare(4500.0);
        flight.setBaggageCabin("7kg");
        flight.setBaggageCheckin("15kg");
        flight.setDepartureTime(LocalDateTime.now());
        flight.setArrivalTime(LocalDateTime.now().plusHours(2));
        flight.setFlightOwner(user);
    }

    @Test
    void testAddFlight() {
        AddFlightRequest request = new AddFlightRequest("AI101", "Air India", 1L, 60, 4500.0, "15kg", "7kg", LocalDateTime.now(), LocalDateTime.now().plusHours(2));

        when(authentication.getName()).thenReturn("admin@example.com");
        when(routeRepository.findById(1L)).thenReturn(Optional.of(route));
        when(userRepository.findByEmail("admin@example.com")).thenReturn(Optional.of(user));
        when(flightRepository.save(any(Flight.class))).thenReturn(flight);

        flightService.addFlight(request, authentication);

        verify(flightRepository).save(any(Flight.class));
        verify(seatRepository).saveAll(anyList());
    }

    @Test
    void testAddFlight_RouteNotFound() {
        AddFlightRequest request = new AddFlightRequest("AI101", "Air India", 99L, 60, 4500.0, "15kg", "7kg", LocalDateTime.now(), LocalDateTime.now().plusHours(2));

        when(routeRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            flightService.addFlight(request, authentication);
        });
    }

    @Test
    void testGetAllFlights() {
        when(flightRepository.findAll()).thenReturn(List.of(flight));

        List<FlightResponse> result = flightService.getAllFlights();

        assertEquals(1, result.size());
        assertEquals("Air India", result.get(0).getFlightName());
    }

    @Test
    void testSearchFlights() {
        FlightSearchRequest request = new FlightSearchRequest("Chennai", "Delhi", LocalDate.now());
        when(flightRepository.findByRoute_OriginAndRoute_DestinationAndDepartureTimeBetween(
                anyString(), anyString(), any(), any())).thenReturn(List.of(flight));

        List<FlightResponse> result = flightService.searchFlights(request);

        assertEquals(1, result.size());
        assertEquals("Delhi", result.get(0).getDestination());
    }

    @Test
    void testGetFlightById_Found() {
        when(flightRepository.findById(1L)).thenReturn(Optional.of(flight));

        FlightResponse result = flightService.getFlightById(1L);

        assertEquals("Air India", result.getFlightName());
        assertEquals("Chennai", result.getOrigin());
    }

    @Test
    void testGetFlightById_NotFound() {
        when(flightRepository.findById(999L)).thenReturn(Optional.empty());

        Exception ex = assertThrows(ResourceNotFoundException.class, () -> {
            flightService.getFlightById(999L);
        });

        assertTrue(ex.getMessage().contains("Flight not found"));
    }

    @Test
    void testUpdateFlightByAdmin_Success() {
        AddFlightRequest updateRequest = new AddFlightRequest("AI999", "Updated Flight", 1L, 80, 4700.0, "20kg", "8kg", LocalDateTime.now(), LocalDateTime.now().plusHours(3));

        when(flightRepository.findById(1L)).thenReturn(Optional.of(flight));
        when(authentication.getName()).thenReturn("admin@example.com");
        when(userRepository.findByEmail("admin@example.com")).thenReturn(Optional.of(user));
        when(routeRepository.findById(1L)).thenReturn(Optional.of(route));

        flightService.updateFlight(1L, updateRequest, authentication);

        verify(flightRepository).save(any(Flight.class));
    }

    @Test
    void testUpdateFlight_UnauthorizedUser() {
        User otherUser = new User();
        otherUser.setEmail("other@example.com");
        otherUser.setRole(Role.USER); // Not ADMIN

        when(flightRepository.findById(1L)).thenReturn(Optional.of(flight));
        when(authentication.getName()).thenReturn("other@example.com");
        when(userRepository.findByEmail("other@example.com")).thenReturn(Optional.of(otherUser));

        AddFlightRequest updateRequest = new AddFlightRequest("AI999", "Unauthorized", 1L, 80, 4700.0, "20kg", "8kg", LocalDateTime.now(), LocalDateTime.now().plusHours(3));

        assertThrows(RuntimeException.class, () -> {
            flightService.updateFlight(1L, updateRequest, authentication);
        });
    }

    @Test
    void testDeleteFlight_Success() {
        when(flightRepository.findById(1L)).thenReturn(Optional.of(flight));
        when(seatRepository.findByFlight(flight)).thenReturn(new ArrayList<>());

        flightService.deleteFlight(1L);

        verify(seatRepository).deleteAll(anyList());
        verify(flightRepository).delete(flight);
    }

    @Test
    void testDeleteFlight_NotFound() {
        when(flightRepository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            flightService.deleteFlight(999L);
        });
    }

    @Test
    void testGetFlightsByOwner_Success() {
        when(userRepository.findByEmail("admin@example.com")).thenReturn(Optional.of(user));
        when(flightRepository.findByFlightOwner(user)).thenReturn(List.of(flight));

        List<FlightResponse> result = flightService.getFlightsByOwner("admin@example.com");

        assertEquals(1, result.size());
        assertEquals("Air India", result.get(0).getFlightName());
    }

    @Test
    void testGetFlightsByOwner_UserNotFound() {
        when(userRepository.findByEmail("unknown@example.com")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            flightService.getFlightsByOwner("unknown@example.com");
        });
    }

    @Test
    void testGetAllUniqueLocations() {
        when(flightRepository.findDistinctOrigins()).thenReturn(List.of("Chennai", "Mumbai"));
        when(flightRepository.findDistinctDestinations()).thenReturn(List.of("Delhi", "Mumbai"));

        List<String> locations = flightService.getAllUniqueLocations();

        assertEquals(3, locations.size());
        assertTrue(locations.contains("Chennai"));
        assertTrue(locations.contains("Delhi"));
        assertTrue(locations.contains("Mumbai"));
    }
}
