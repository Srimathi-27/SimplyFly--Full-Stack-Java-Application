package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.AddFlightRequest;
import com.simplyfly.airticketbooking.dto.FlightResponse;
import com.simplyfly.airticketbooking.dto.FlightSearchRequest;
import org.springframework.security.core.Authentication;

import java.util.List;

public interface FlightService {
    void addFlight(AddFlightRequest request, Authentication authentication);
    List<FlightResponse> getAllFlights();
    List<FlightResponse> searchFlights(FlightSearchRequest request);
    void deleteFlight(Long id);
    FlightResponse getFlightById(Long id);
    void updateFlight(Long id, AddFlightRequest request, Authentication authentication);

    // ✅ Newly added: Get flights added by the current flight owner
    List<FlightResponse> getFlightsByOwner(String email);
    List<String> getAllUniqueLocations();

}
