package com.simplyfly.airticketbooking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DashboardStatsResponse {
    private long users;
    private long flightOwners;
    private long flights;
    private long bookings;
    private long routes;
    private long payments;
}
