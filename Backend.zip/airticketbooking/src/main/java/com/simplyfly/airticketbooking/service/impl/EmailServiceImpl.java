package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.service.EmailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EmailServiceImpl implements EmailService {

    @Override
    public void sendPaymentNotification(String to, String subject, String body) {
        log.info("📧 Sending email to: {}\nSubject: {}\nBody: {}", to, subject, body);
    }
}

