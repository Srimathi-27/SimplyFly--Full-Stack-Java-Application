package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.PaymentRequest;
import com.simplyfly.airticketbooking.dto.PaymentResponse;
import com.simplyfly.airticketbooking.entity.Booking;
import com.simplyfly.airticketbooking.entity.Flight;
import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.entity.Payment;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.BookingRepository;
import com.simplyfly.airticketbooking.repository.PaymentRepository;
import com.simplyfly.airticketbooking.repository.UserRepository;
import com.simplyfly.airticketbooking.service.EmailService;
import com.simplyfly.airticketbooking.service.PaymentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final EmailService emailService;

    @Override
    public PaymentResponse makePayment(PaymentRequest request) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (!"BOOKED".equals(booking.getStatus())) {
            throw new RuntimeException("Cannot pay for this booking as it's not in BOOKED state");
        }

        if (paymentRepository.existsByBooking(booking)) {
            throw new RuntimeException("Payment already completed for this booking.");
        }

        
        // Frontend takes care of status
        String paymentStatus = request.getStatus() != null ? request.getStatus() : "PAID";


        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setPaymentMethod(request.getPaymentMethod());
        payment.setAmount(booking.getTotalPrice());
        payment.setStatus(paymentStatus);
        payment.setPaymentTime(LocalDateTime.now());

        Payment savedPayment = paymentRepository.save(payment);

        log.info("Payment [{}] created for Booking ID: {} with status: {}", savedPayment.getId(), booking.getId(), paymentStatus);

        // ✉️ Send email if PAID or FAILED
        if (paymentStatus.equals("PAID") || paymentStatus.equals("FAILED")) {
            String subject = "Payment " + paymentStatus;
            String body = String.format("Hello %s,\nYour payment for Booking ID %d has %s.\nAmount: ₹%.2f",
                    booking.getUser().getName(), booking.getId(), paymentStatus.toLowerCase(), booking.getTotalPrice());

            emailService.sendPaymentNotification(booking.getUser().getEmail(), subject, body);
        }

        return new PaymentResponse(
                savedPayment.getId(),
                savedPayment.getStatus(),
                savedPayment.getAmount(),
                "Payment " + paymentStatus.toLowerCase()
        );
    }

    @Override
    public List<PaymentResponse> getPaymentsForUser(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return paymentRepository.findByBooking_User(user).stream()
                .map(payment -> new PaymentResponse(
                        payment.getId(),
                        payment.getStatus(),
                        payment.getAmount(),
                        "Booking ID: " + payment.getBooking().getId()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public List<PaymentResponse> getAllPayments() {
        return paymentRepository.findAll().stream()
                .map(payment -> new PaymentResponse(
                        payment.getId(),
                        payment.getStatus(),
                        payment.getAmount(),
                        "Booking ID: " + payment.getBooking().getId()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public PaymentResponse retryPayment(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        Payment existingPayment = paymentRepository.findByBooking(booking)
                .orElseThrow(() -> new RuntimeException("No payment found to retry."));

        if ("PAID".equals(existingPayment.getStatus())) {
            throw new RuntimeException("Payment is already successful. No need to retry.");
        }

        List<String> statuses = Arrays.asList("PAID", "FAILED", "PENDING");
        Collections.shuffle(statuses);
        String newStatus = statuses.get(0);

        existingPayment.setStatus(newStatus);
        existingPayment.setPaymentTime(LocalDateTime.now());

        Payment saved = paymentRepository.save(existingPayment);

        log.info("Retried payment ID {} - new status: {}", saved.getId(), newStatus);

        // ✉️ Notify only if retry results in PAID or FAILED
        if (newStatus.equals("PAID") || newStatus.equals("FAILED")) {
            String subject = "Payment Retry: " + newStatus;
            String body = String.format("Dear %s,\nYour payment retry for Booking ID %d has %s.\nAmount: ₹%.2f",
                    booking.getUser().getName(), booking.getId(), newStatus.toLowerCase(), booking.getTotalPrice());

            emailService.sendPaymentNotification(booking.getUser().getEmail(), subject, body);
        }

        return new PaymentResponse(
                saved.getId(),
                saved.getStatus(),
                saved.getAmount(),
                "Payment retry result: " + newStatus
        );
    }
    @Override
    public String refundPayment(Long bookingId, String requesterEmail) {
        // 🔎 Find the booking
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        // ✅ Only cancelled bookings can be refunded
        if (!"CANCELLED".equalsIgnoreCase(booking.getStatus())) {
            throw new RuntimeException("Only cancelled bookings can be refunded.");
        }

        // 🔐 Authorization check
        Flight flight = booking.getFlight();
        if (flight == null || flight.getFlightOwner() == null) {
            throw new RuntimeException("Flight owner not available for authorization.");
        }

        // ⛔ Check if the requester is either admin or flight owner
        User requester = userRepository.findByEmail(requesterEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        boolean isAdmin = requester.getRole().name().equals("ROLE_ADMIN");
        boolean isFlightOwner = flight.getFlightOwner().getEmail().equalsIgnoreCase(requesterEmail);

        if (!isAdmin && !isFlightOwner) {
            throw new RuntimeException("You are not authorized to refund this booking.");
        }

        // 💳 Get the associated payment
        Payment payment = paymentRepository.findByBooking(booking)
                .orElseThrow(() -> new RuntimeException("Payment record not found."));

        // ❌ Allow refund only if payment is PAID
        if (!"PAID".equalsIgnoreCase(payment.getStatus())) {
            throw new RuntimeException("Only PAID payments can be refunded.");
        }

        // 💸 Process refund
        payment.setStatus("REFUNDED");
        payment.setRefundTime(LocalDateTime.now());
        paymentRepository.save(payment);

        // ✉️ Email Notification
        String subject = "Payment Refunded";
        String body = String.format(
            "Hi %s,\n\nYour payment for Booking ID %d has been successfully refunded.\nRefunded Amount: ₹%.2f\n\nThank you for using SimplyFly.",
            booking.getUser().getName(),
            booking.getId(),
            payment.getAmount()
        );
        emailService.sendPaymentNotification(booking.getUser().getEmail(), subject, body);

        return "Refund processed successfully.";
    }


}
