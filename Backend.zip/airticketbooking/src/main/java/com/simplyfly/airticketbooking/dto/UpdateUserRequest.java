package com.simplyfly.airticketbooking.dto;

import lombok.Data;

@Data
public class UpdateUserRequest {
    private String name;
    private String gender;
    private String contactNumber;
    private String address;
}
