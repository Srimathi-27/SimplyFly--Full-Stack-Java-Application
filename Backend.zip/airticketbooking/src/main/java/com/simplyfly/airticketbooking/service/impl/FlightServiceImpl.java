package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.AddFlightRequest;
import com.simplyfly.airticketbooking.dto.FlightResponse;
import com.simplyfly.airticketbooking.dto.FlightSearchRequest;
import com.simplyfly.airticketbooking.entity.*;
import com.simplyfly.airticketbooking.enums.SeatClass;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.*;
import com.simplyfly.airticketbooking.service.FlightService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;
    private final RouteRepository routeRepository;
    private final UserRepository userRepository;
    private final SeatRepository seatRepository;

    @Override
    public void addFlight(AddFlightRequest request, Authentication authentication) {
        log.info("Attempting to add flight: {} by user: {}", request.getFlightNumber(), authentication.getName());

        Route route = routeRepository.findById(request.getRouteId())
                .orElseThrow(() -> new ResourceNotFoundException("Route not found"));

        String userEmail = authentication.getName();
        User owner = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Flight flight = new Flight();
        flight.setFlightNumber(request.getFlightNumber());
        flight.setFlightName(request.getFlightName());
        flight.setRoute(route);
        flight.setTotalSeats(request.getTotalSeats());
        flight.setFare(request.getFare());
        flight.setBaggageCheckin(request.getBaggageCheckin());
        flight.setBaggageCabin(request.getBaggageCabin());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());
        flight.setFlightOwner(owner);

        Flight savedFlight = flightRepository.save(flight);

        // Generate and save seat layout
        List<Seat> seats = generateSeatsForFlight(savedFlight);
        seatRepository.saveAll(seats);

        log.info("Flight added successfully with {} seats", seats.size());
    }

    @Override
    public List<FlightResponse> getAllFlights() {
        return flightRepository.findAll().stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<FlightResponse> searchFlights(FlightSearchRequest request) {
        LocalDateTime start = request.getDepartureDate().atStartOfDay();
        LocalDateTime end = request.getDepartureDate().atTime(23, 59, 59);

        List<Flight> flights = flightRepository
                .findByRoute_OriginAndRoute_DestinationAndDepartureTimeBetween(
                        request.getOrigin(), request.getDestination(), start, end);

        return flights.stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }

    @Override
    public FlightResponse getFlightById(Long id) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        return mapToFlightResponse(flight);
    }

    @Override
    public void updateFlight(Long id, AddFlightRequest request, Authentication authentication) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        User user = userRepository.findByEmail(authentication.getName())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!user.getRole().name().equals("ADMIN") &&
                !flight.getFlightOwner().getEmail().equals(user.getEmail())) {
            throw new RuntimeException("Access denied to update flight");
        }

        Route route = routeRepository.findById(request.getRouteId())
                .orElseThrow(() -> new ResourceNotFoundException("Route not found"));

        flight.setFlightNumber(request.getFlightNumber());
        flight.setFlightName(request.getFlightName());
        flight.setRoute(route);
        flight.setFare(request.getFare());
        flight.setTotalSeats(request.getTotalSeats());
        flight.setBaggageCheckin(request.getBaggageCheckin());
        flight.setBaggageCabin(request.getBaggageCabin());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());

        flightRepository.save(flight);
        log.info("Flight with ID {} updated successfully", id);
    }

    @Override
    public void deleteFlight(Long id) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));
     // Delete related seats first
        List<Seat> seats = seatRepository.findByFlight(flight);
        seatRepository.deleteAll(seats);

        // Now delete the flight
        flightRepository.delete(flight);
        log.info("Flight with ID {} deleted", id);
    }

    @Override
    public List<FlightResponse> getFlightsByOwner(String email) {
        User owner = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return flightRepository.findByFlightOwner(owner).stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }

    private List<Seat> generateSeatsForFlight(Flight flight) {
        List<Seat> seats = new ArrayList<>();
        int totalSeats = flight.getTotalSeats();
        String[] seatColumns = {"A", "B", "C", "D", "E", "F"}; // 6 seats per row
        int seatsPerRow = seatColumns.length;
        int totalRows = (int) Math.ceil((double) totalSeats / seatsPerRow);

        for (int row = 1; row <= totalRows; row++) {
            SeatClass seatClass = (row <= 2) ? SeatClass.BUSINESS : SeatClass.ECONOMY;

            for (String col : seatColumns) {
                if (seats.size() >= totalSeats) break;

                String seatNumber = row + col;
                Seat seat = new Seat();
                seat.setSeatNumber(seatNumber);
                seat.setBooked(false);
                seat.setStatus("AVAILABLE");
                seat.setSeatClass(seatClass);
                seat.setFlight(flight);
                seat.setBooking(null);
                seats.add(seat);
            }
        }

        return seats;
    }


    private FlightResponse mapToFlightResponse(Flight flight) {
        return new FlightResponse(
                flight.getId(),
                flight.getFlightNumber(),
                flight.getFlightName(),
                flight.getRoute().getOrigin(),
                flight.getRoute().getDestination(),
                flight.getRoute().getId(),
                flight.getFare(),
                flight.getTotalSeats(),
                flight.getBaggageCheckin(),
                flight.getBaggageCabin(),
                flight.getDepartureTime(),
                flight.getArrivalTime(),
                flight.getFlightOwner().getEmail()
        );
    }
    @Override
    public List<String> getAllUniqueLocations() {
        List<String> origins = flightRepository.findDistinctOrigins();
        List<String> destinations = flightRepository.findDistinctDestinations();

        Set<String> allLocations = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        allLocations.addAll(origins);
        allLocations.addAll(destinations);

        return new ArrayList<>(allLocations);
    }

}
