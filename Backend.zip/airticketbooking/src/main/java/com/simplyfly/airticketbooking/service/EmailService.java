package com.simplyfly.airticketbooking.service;

public interface EmailService {
    void sendPaymentNotification(String to, String subject, String body);
}
