package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.AddRouteRequest;
import com.simplyfly.airticketbooking.dto.RouteResponse;
import com.simplyfly.airticketbooking.service.RouteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/routes")
@RequiredArgsConstructor
public class RouteController {

    private final RouteService routeService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<RouteResponse> addRoute(@RequestBody AddRouteRequest request) {
        RouteResponse response = routeService.addRoute(request);
        return ResponseEntity.ok(response);
    }


    @GetMapping
    public ResponseEntity<List<RouteResponse>> getAllRoutes() {
        log.info("GET /api/routes - Fetching all routes");
        return ResponseEntity.ok(routeService.getAllRoutes());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<String> updateRoute(@PathVariable Long id, @RequestBody AddRouteRequest request) {
        routeService.updateRoute(id, request);
        return ResponseEntity.ok("Route updated successfully");
    }
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<String> deleteRoute(@PathVariable Long id) {
        log.info("DELETE /api/routes/{} - Deleting route", id);
        routeService.deleteRoute(id);
        return ResponseEntity.ok("Route deleted successfully");
    }

   

}

