package com.simplyfly.airticketbooking.dto;
import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PasswordChangeRequest {
    private String currentPassword;
    private String newPassword;
}
