package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.SeatDTO;
import com.simplyfly.airticketbooking.service.SeatService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/seats")
@RequiredArgsConstructor
public class SeatController {

    private final SeatService seatService;

    // 🔹 Basic: Get all seats for a flight (booked + available)
    @GetMapping("/flight/{flightId}/all")
    @PreAuthorize("hasAnyAuthority('ROLE_USER', 'ROLE_ADMIN', 'ROLE_FLIGHT_OWNER')")
    public ResponseEntity<List<SeatDTO>> getAllSeatsByFlight(@PathVariable Long flightId) {
        log.info("GET /api/seats/flight/{}/all", flightId);
        return ResponseEntity.ok(seatService.getSeatsByFlightId(flightId, false));
    }

    // 🔹 Filtered: Get only available seats
    @GetMapping("/flight/{flightId}/available")
    @PreAuthorize("hasAnyAuthority('ROLE_USER', 'ROLE_ADMIN', 'ROLE_FLIGHT_OWNER')")
    public ResponseEntity<List<SeatDTO>> getAvailableSeatsByFlight(@PathVariable Long flightId) {
        log.info("GET /api/seats/flight/{}/available", flightId);
        return ResponseEntity.ok(seatService.getSeatsByFlightId(flightId, true));
    }

    // 🔹 Grouped: Get seat map grouped by row (A, B, etc.)
    @GetMapping("/flight/{flightId}/grouped")
    @PreAuthorize("hasAnyAuthority('ROLE_USER', 'ROLE_ADMIN', 'ROLE_FLIGHT_OWNER')")
    public ResponseEntity<Map<String, List<SeatDTO>>> getGroupedSeatsByFlight(@PathVariable Long flightId,
                                                                              @RequestParam(defaultValue = "false") boolean onlyAvailable) {
        log.info("GET /api/seats/flight/{}/grouped?available={}", flightId, onlyAvailable);
        return ResponseEntity.ok(seatService.getGroupedSeatsByFlightId(flightId, onlyAvailable));
    }
    @PutMapping("/{seatId}/block")
    @PreAuthorize("hasAuthority('ROLE_FLIGHT_OWNER')")
    public ResponseEntity<String> blockSeat(@PathVariable Long seatId) {
        seatService.blockSeat(seatId);
        return ResponseEntity.ok("Seat blocked successfully");
    }

    @PutMapping("/{seatId}/unblock")
    @PreAuthorize("hasAuthority('ROLE_FLIGHT_OWNER')")
    public ResponseEntity<String> unblockSeat(@PathVariable Long seatId) {
        seatService.unblockSeat(seatId);
        return ResponseEntity.ok("Seat unblocked successfully");
    }

}



