package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.SeatDTO;

import java.util.List;
import java.util.Map;

public interface SeatService {

    /**
     * Get only available seats for a given flight.
     * @param flightId flight ID
     * @return list of available SeatDTO
     */
    List<SeatDTO> getAvailableSeatsByFlightId(Long flightId);

    /**
     * Get all or only available seats depending on flag.
     * @param flightId flight ID
     * @param onlyAvailable if true, filters only available seats
     * @return list of SeatDTO
     */
    List<SeatDTO> getSeatsByFlightId(Long flightId, boolean onlyAvailable);

    /**
     * Get seat map grouped by row (e.g., "1", "2", "3") for a flight.
     * Grouping logic should be based on seat number's row part (e.g., "1A" → row "1").
     * @param flightId flight ID
     * @param onlyAvailable whether to include only available seats
     * @return map of row key to list of SeatDTO
     */
    Map<String, List<SeatDTO>> getGroupedSeatsByFlightId(Long flightId, boolean onlyAvailable);
    
    void blockSeat(Long seatId);
    void unblockSeat(Long seatId);

}
