package com.simplyfly.airticketbooking.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddFlightRequest {
	
	
    @NotBlank(message = "Flight number is required")
    private String flightNumber;

    @NotBlank(message = "Flight name is required")
    private String flightName;

    @NotNull(message = "Route ID is required")
    private Long routeId;

    @Min(value = 1, message = "Total seats must be at least 1")
    private int totalSeats;

    @DecimalMin(value = "0.0", inclusive = false, message = "Fare must be positive")
    private double fare;

    @NotBlank(message = "Baggage check-in info is required")
    private String baggageCheckin;

    @NotBlank(message = "Baggage cabin info is required")
    private String baggageCabin;

    @NotNull(message = "Departure time is required")
    private LocalDateTime departureTime;

    @NotNull(message = "Arrival time is required")
    private LocalDateTime arrivalTime;
}
