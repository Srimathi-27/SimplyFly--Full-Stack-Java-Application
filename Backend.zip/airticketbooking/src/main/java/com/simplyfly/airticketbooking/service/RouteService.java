package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.AddRouteRequest;
import com.simplyfly.airticketbooking.dto.RouteResponse;
import java.util.*;

public interface RouteService {
	RouteResponse addRoute(AddRouteRequest request);
    List<RouteResponse> getAllRoutes();
    void updateRoute(Long id, AddRouteRequest request);
    void deleteRoute(Long id);
}
