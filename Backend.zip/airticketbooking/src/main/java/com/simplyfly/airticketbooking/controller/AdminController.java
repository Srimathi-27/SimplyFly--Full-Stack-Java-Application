package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.DashboardStatsResponse;
import com.simplyfly.airticketbooking.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@Slf4j
public class AdminController {

    private final AdminService adminService;

    // GET /api/admin/dashboard-stats
    @GetMapping("/dashboard-stats")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<DashboardStatsResponse> getDashboardStats() {
        log.info("GET /api/admin/dashboard-stats");
        return ResponseEntity.ok(adminService.getDashboardStats());
    }
}

