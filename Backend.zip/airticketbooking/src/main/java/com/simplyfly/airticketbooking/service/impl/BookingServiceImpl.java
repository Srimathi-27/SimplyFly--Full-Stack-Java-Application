package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.BookingRequest;
import com.simplyfly.airticketbooking.dto.BookingResponse;
import com.simplyfly.airticketbooking.entity.*;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.*;
import com.simplyfly.airticketbooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final SeatRepository seatRepository;
    private final UserRepository userRepository;
    private final FlightRepository flightRepository;
    private final PaymentRepository paymentRepository;

    @Override
    public BookingResponse bookFlight(BookingRequest request, Authentication authentication) {
        String userEmail = authentication.getName();
        log.info("Starting booking for user: {}", userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        List<Seat> availableSeats = seatRepository.findByFlightAndIsBookedFalse(flight);

        // Build map of available seat number to Seat object
        Map<String, Seat> availableSeatMap = availableSeats.stream()
                .collect(Collectors.toMap(Seat::getSeatNumber, seat -> seat));

        List<Seat> selectedSeats = new ArrayList<>();
        for (String seatNumber : request.getSeatNumbers()) {
            Seat seat = availableSeatMap.get(seatNumber);
            if (seat == null) {
                throw new RuntimeException("Seat " + seatNumber + " is not available or does not exist.");
            }
         // ✅ Reject if blocked
            if ("BLOCKED".equalsIgnoreCase(seat.getStatus())) {
                throw new RuntimeException("Seat " + seatNumber + " is blocked and cannot be booked.");
            }
            selectedSeats.add(seat);
        }

        if (selectedSeats.size() != request.getSeatCount()) {
            throw new RuntimeException("Mismatch between requested seat count and seat numbers.");
        }

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setFlight(flight);
        booking.setBookingDate(LocalDateTime.now());
        booking.setSeatCount(request.getSeatCount());
        booking.setTotalPrice(flight.getFare() * request.getSeatCount());
        booking.setStatus("BOOKED");

        Booking savedBooking = bookingRepository.save(booking);

        for (Seat seat : selectedSeats) {
            seat.setBooked(true);
            seat.setBooking(savedBooking);
        }

        seatRepository.saveAll(selectedSeats);

        List<String> bookedSeatNumbers = selectedSeats.stream()
                .map(Seat::getSeatNumber)
                .collect(Collectors.toList());

        String paymentStatus = paymentRepository.findByBooking(savedBooking)
                .map(Payment::getStatus)
                .orElse("UNPAID");

        return new BookingResponse(
                savedBooking.getId(),
                flight.getFlightNumber(),
                flight.getFlightName(),
                flight.getRoute().getOrigin(),
                flight.getRoute().getDestination(),
                savedBooking.getSeatCount(),
                savedBooking.getTotalPrice(),
                savedBooking.getStatus(),
                savedBooking.getBookingDate(),
                bookedSeatNumbers,
                paymentStatus
        );
    }

    @Override
    public List<BookingResponse> getMyBookings(Authentication authentication) {
        String userEmail = authentication.getName();
        log.info("Retrieving bookings for user: {}", userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        List<Booking> bookings = bookingRepository.findByUser(user);

        return bookings.stream().map(booking -> {
            Flight flight = booking.getFlight();
            List<String> bookedSeats = seatRepository.findByBookingId(booking.getId())
                    .stream().map(Seat::getSeatNumber).collect(Collectors.toList());

            String paymentStatus = paymentRepository.findByBooking(booking)
                    .map(Payment::getStatus)
                    .orElse("UNPAID");

            return new BookingResponse(
                    booking.getId(),
                    flight.getFlightNumber(),
                    flight.getFlightName(),
                    flight.getRoute().getOrigin(),
                    flight.getRoute().getDestination(),
                    booking.getSeatCount(),
                    booking.getTotalPrice(),
                    booking.getStatus(),
                    booking.getBookingDate(),
                    bookedSeats,
                    paymentStatus
            );
        }).collect(Collectors.toList());
    }

    @Override
    public String cancelBooking(Long bookingId, Authentication authentication) {
        String userEmail = authentication.getName();
        log.info("Attempting to cancel booking ID: {} by user: {}", bookingId, userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (!user.getRole().name().equals("ADMIN") &&
        	    !booking.getUser().getId().equals(user.getId())) {
        	    throw new RuntimeException("You are not allowed to cancel this booking");
        	}


        if (!"BOOKED".equals(booking.getStatus())) {
            throw new RuntimeException("Only booked tickets can be cancelled");
        }

        booking.setStatus("CANCELLED");
        bookingRepository.save(booking);

        List<Seat> seats = seatRepository.findByBookingId(bookingId);
        for (Seat seat : seats) {
            seat.setBooked(false);
            seat.setBooking(null);
        }
        seatRepository.saveAll(seats);

        return "Booking cancelled successfully.";
    }

    @Override
    public List<BookingResponse> getAllBookings() {
        log.info("Admin request: retrieving all bookings in system");

        List<Booking> bookings = bookingRepository.findAll();

        return bookings.stream().map(booking -> {
            Flight flight = booking.getFlight();
            List<String> bookedSeats = seatRepository.findByBookingId(booking.getId())
                    .stream().map(Seat::getSeatNumber).collect(Collectors.toList());

            String paymentStatus = paymentRepository.findByBooking(booking)
                    .map(Payment::getStatus)
                    .orElse("UNPAID");

            return new BookingResponse(
                    booking.getId(),
                    flight.getFlightNumber(),
                    flight.getFlightName(),
                    flight.getRoute().getOrigin(),
                    flight.getRoute().getDestination(),
                    booking.getSeatCount(),
                    booking.getTotalPrice(),
                    booking.getStatus(),
                    booking.getBookingDate(),
                    bookedSeats,
                    paymentStatus
            );
        }).collect(Collectors.toList());
    }
    @Override
    public List<BookingResponse> getBookingsForFlightOwner(String email) {
        log.info("Fetching bookings for flights owned by: {}", email);

        // 1. Find the owner
        User owner = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Flight owner not found"));

        // 2. Get all flights owned by them
        List<Flight> ownedFlights = flightRepository.findByFlightOwner(owner);

        // 3. Get bookings for each flight
        List<Booking> bookings = bookingRepository.findByFlightIn(ownedFlights);

        // 4. Convert to BookingResponse
        return bookings.stream().map(booking -> {
            Flight flight = booking.getFlight();
            List<String> seats = seatRepository.findByBookingId(booking.getId())
                    .stream().map(Seat::getSeatNumber).collect(Collectors.toList());

            String paymentStatus = paymentRepository.findByBooking(booking)
                    .map(Payment::getStatus)
                    .orElse("UNPAID");

            return new BookingResponse(
                    booking.getId(),
                    flight.getFlightNumber(),
                    flight.getFlightName(),
                    flight.getRoute().getOrigin(),
                    flight.getRoute().getDestination(),
                    booking.getSeatCount(),
                    booking.getTotalPrice(),
                    booking.getStatus(),
                    booking.getBookingDate(),
                    seats,
                    paymentStatus
            );
        }).collect(Collectors.toList());
    }

}

