package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.AddRouteRequest;
import com.simplyfly.airticketbooking.dto.RouteResponse;
import com.simplyfly.airticketbooking.entity.Route;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.FlightRepository;
import com.simplyfly.airticketbooking.repository.RouteRepository;
import com.simplyfly.airticketbooking.service.RouteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RouteServiceImpl implements RouteService {

    private final RouteRepository routeRepository;
    private final FlightRepository flightRepository;

    @Override
    public RouteResponse addRoute(AddRouteRequest request) {
        log.info("Attempting to add route: {} -> {}", request.getOrigin(), request.getDestination());

        boolean exists = routeRepository.existsByOriginAndDestination(
                request.getOrigin(), request.getDestination()
        );

        if (exists) {
            log.warn("Route already exists: {} -> {}", request.getOrigin(), request.getDestination());
            throw new RuntimeException("Route already exists.");
        }

        Route route = new Route(
                null,
                request.getOrigin(),
                request.getDestination(),
                request.getDistanceInKm(),
                request.getDuration()
        );

        Route savedRoute = routeRepository.save(route);

        log.info("Route successfully added: {} -> {}", savedRoute.getOrigin(), savedRoute.getDestination());

        return new RouteResponse(
                savedRoute.getId(),
                savedRoute.getOrigin(),
                savedRoute.getDestination(),
                savedRoute.getDistanceInKm(),
                savedRoute.getDuration()
        );
    }

    @Override
    public List<RouteResponse> getAllRoutes() {
        return routeRepository.findAll().stream().map(route ->
            new RouteResponse(
                route.getId(),
                route.getOrigin(),
                route.getDestination(),
                route.getDistanceInKm(),
                route.getDuration()
            )
        ).collect(Collectors.toList());
    }

    @Override
    public void updateRoute(Long id, AddRouteRequest request) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Route not found"));

        route.setOrigin(request.getOrigin());
        route.setDestination(request.getDestination());
        route.setDistanceInKm(request.getDistanceInKm());
        route.setDuration(request.getDuration());

        routeRepository.save(route);
        log.info("Route with ID {} updated successfully", id);
    }
    @Override
    public void deleteRoute(Long id) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Route not found"));

        // Check if any flight is using this route
        boolean isInUse = flightRepository.existsByRoute(route);
        if (isInUse) {
            throw new RuntimeException("Cannot delete route. It is currently assigned to one or more flights.");
        }

        routeRepository.delete(route);
        log.info("Route with ID {} deleted successfully", id);
    }


}