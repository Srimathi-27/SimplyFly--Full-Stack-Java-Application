package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.SeatDTO;
import com.simplyfly.airticketbooking.entity.Flight;
import com.simplyfly.airticketbooking.entity.Seat;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.FlightRepository;
import com.simplyfly.airticketbooking.repository.SeatRepository;
import com.simplyfly.airticketbooking.service.SeatService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SeatServiceImpl implements SeatService {

    private final FlightRepository flightRepository;
    private final SeatRepository seatRepository;

    @Override
    public List<SeatDTO> getAvailableSeatsByFlightId(Long flightId) {
        log.info("Fetching available seats for flight ID: {}", flightId);
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        return seatRepository.findByFlightAndIsBookedFalse(flight)
                .stream()
                .map(seat -> new SeatDTO(
                        seat.getId(),
                        seat.getSeatNumber(),
                        false,
                        seat.getSeatClass(),
                        seat.getStatus()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public List<SeatDTO> getSeatsByFlightId(Long flightId, boolean onlyAvailable) {
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        List<Seat> seats = onlyAvailable
                ? seatRepository.findByFlightAndIsBookedFalse(flight)
                : seatRepository.findByFlight(flight);

        return seats.stream()
                .map(seat -> new SeatDTO(
                        seat.getId(),
                        seat.getSeatNumber(),
                        seat.isBooked(),
                        seat.getSeatClass(),
                        seat.getStatus()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public Map<String, List<SeatDTO>> getGroupedSeatsByFlightId(Long flightId, boolean onlyAvailable) {
        List<Seat> seats = onlyAvailable
            ? seatRepository.findByFlightIdAndIsBookedFalse(flightId)
            : seatRepository.findByFlightId(flightId);

        log.info("Total seats fetched for flight ID {}: {}", flightId, seats.size());

        List<SeatDTO> seatDTOs = seats.stream()
            .map(seat -> new SeatDTO(
                seat.getId(),
                seat.getSeatNumber(),
                seat.isBooked(),
                seat.getSeatClass(),
                seat.getStatus()
            ))
            .toList();

        return seatDTOs.stream()
            .collect(Collectors.groupingBy(seat -> {
                String seatNumber = seat.getSeatNumber();
                if (seatNumber == null || seatNumber.isEmpty()) return "0";
                return seatNumber.replaceAll("[^0-9]", "");
            }));
    }
    @Override
    public void blockSeat(Long seatId) {
        Seat seat = seatRepository.findById(seatId)
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found"));

        if (seat.isBooked()) {
            throw new IllegalStateException("Cannot block a booked seat");
        }

        seat.setStatus("BLOCKED");
        seatRepository.save(seat);
        log.info("Seat {} blocked", seat.getSeatNumber());
    }

    @Override
    public void unblockSeat(Long seatId) {
        Seat seat = seatRepository.findById(seatId)
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found"));

        if (seat.isBooked()) {
            throw new IllegalStateException("Cannot unblock a booked seat");
        }

        seat.setStatus("AVAILABLE");
        seatRepository.save(seat);
        log.info("Seat {} unblocked", seat.getSeatNumber());
    }



    
}
