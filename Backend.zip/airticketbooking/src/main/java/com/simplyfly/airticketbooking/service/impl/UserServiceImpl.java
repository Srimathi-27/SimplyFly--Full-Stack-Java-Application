package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.AuthResponse;
import com.simplyfly.airticketbooking.dto.LoginRequest;
import com.simplyfly.airticketbooking.dto.RegisterRequest;
import com.simplyfly.airticketbooking.entity.PasswordResetToken;
import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.enums.Role;
import com.simplyfly.airticketbooking.repository.UserRepository;
import com.simplyfly.airticketbooking.security.JwtTokenUtil;
import com.simplyfly.airticketbooking.service.UserService;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.simplyfly.airticketbooking.dto.PasswordChangeRequest;
import com.simplyfly.airticketbooking.exception.UsernameNotFoundException;
import com.simplyfly.airticketbooking.dto.UpdateUserRequest;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.FlightRepository;
import com.simplyfly.airticketbooking.repository.BookingRepository;
import com.simplyfly.airticketbooking.repository.PasswordResetTokenRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenUtil jwtTokenUtil;
    private final AuthenticationManager authenticationManager;
    private final BookingRepository bookingRepository;
    private final FlightRepository flightRepository;
    private final PasswordResetTokenRepository passwordResetTokenRepository;

    // 🔐 Register
    @Override
    public AuthResponse registerUser(RegisterRequest request) {
        log.info("Attempting to register user with email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            log.warn("Registration failed - email already in use: {}", request.getEmail());
            throw new RuntimeException("Email already in use");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setGender(request.getGender());
        user.setContactNumber(request.getContactNumber());
        user.setAddress(request.getAddress());
        user.setRole(request.getRole() != null ? request.getRole() : Role.USER);

        userRepository.save(user);
        //log.info("User registered successfully: {}", request.getEmail());

        String token = jwtTokenUtil.generateToken(user.getEmail(), user.getRole().name());

        return new AuthResponse(token, user.getRole().name(), "User registered successfully");
    }

    // 🔐 Login
    @Override
    public AuthResponse authenticateUser(LoginRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.error("User not found during login: {}", request.getEmail());
                    return new RuntimeException("User not found");
                });

        log.info("Login successful for user: {}", request.getEmail());
        String token = jwtTokenUtil.generateToken(user.getEmail(), user.getRole().name());

        return new AuthResponse(token, user.getRole().name(), "Login successful");
    }

    // 👤 User profile
    @Override
    public User getCurrentUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public User updateCurrentUser(String email, UpdateUserRequest request) {
        User user = getCurrentUser(email);
        user.setName(request.getName());
        user.setGender(request.getGender());
        user.setContactNumber(request.getContactNumber());
        user.setAddress(request.getAddress());
        return userRepository.save(user);
    }

    
    @Override
    public void changePassword(String email, String currentPassword, String newPassword) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));

        // ✅ Check if current password matches
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new IllegalArgumentException("Current password is incorrect.");
        }

        // ✅ Encode and update new password
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }


    // 🛠️ Admin methods
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public void deleteUser(Long id) {
    	User user = userRepository.findById(id)
    	        .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    	    // Check if the user has any bookings
    	    boolean hasBookings = !bookingRepository.findByUser(user).isEmpty();

    	    // Check if the user owns any flights
    	    boolean ownsFlights = !flightRepository.findByFlightOwner(user).isEmpty();

    	    if (hasBookings || ownsFlights) {
    	        throw new RuntimeException("Cannot delete user. The user is associated with existing bookings or flights.");
    	    }
        userRepository.deleteById(id);
    }
    
    public String generateResetLink(String email) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isEmpty()) return null;

        User user = userOpt.get();
        String token = UUID.randomUUID().toString();

        PasswordResetToken resetToken = new PasswordResetToken();
        resetToken.setToken(token);
        resetToken.setUser(user);
        resetToken.setExpiryDate(LocalDateTime.now().plusMinutes(30));

        passwordResetTokenRepository.save(resetToken);

        return "http://localhost:4200/auth/reset-password?token=" + token;
    }


    @Override
    public boolean resetPassword(String token, String newPassword) {
        Optional<PasswordResetToken> tokenOpt = passwordResetTokenRepository.findByToken(token);
        if (tokenOpt.isEmpty()) return false;

        PasswordResetToken resetToken = tokenOpt.get();
        if (resetToken.getExpiryDate().isBefore(LocalDateTime.now())) return false;

        User user = resetToken.getUser();
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
        passwordResetTokenRepository.delete(resetToken); // Invalidate token
        return true;
    }


}
