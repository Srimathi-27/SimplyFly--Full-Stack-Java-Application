package com.simplyfly.airticketbooking.enums;

public enum Role {
    USER,
    FLIGHT_OWNER,
    ADMIN
}
