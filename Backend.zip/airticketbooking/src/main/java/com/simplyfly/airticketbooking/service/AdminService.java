package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.DashboardStatsResponse;

public interface AdminService {
    DashboardStatsResponse getDashboardStats();
}

