package com.simplyfly.airticketbooking.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RouteResponse {
    private Long id;
    private String origin;
    private String destination;
    private int distanceInKm;
    private String duration;
}
