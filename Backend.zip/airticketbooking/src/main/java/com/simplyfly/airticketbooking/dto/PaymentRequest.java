package com.simplyfly.airticketbooking.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest {
    private Long bookingId;
    private String paymentMethod;
    private String status; 
}
