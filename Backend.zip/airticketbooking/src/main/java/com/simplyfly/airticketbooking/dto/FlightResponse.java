package com.simplyfly.airticketbooking.dto;

import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FlightResponse {
    private Long id;
    private String flightNumber;
    private String flightName;
    private String origin;
    private String destination;
    private Long routeId;

    private double fare;
    private int totalSeats; // ✅ Add totalSeats if needed for managing capacity
    private String baggageCheckin; // ✅ For user visibility
    private String baggageCabin;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;

    private String flightOwnerEmail; // ✅ Useful for Admins to identify ownership
}
