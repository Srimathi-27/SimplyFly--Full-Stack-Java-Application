package com.simplyfly.airticketbooking.repository;

import com.simplyfly.airticketbooking.entity.Payment;
import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    // ✅ Prevent double payment for the same booking
    boolean existsByBooking(Booking booking);

    // ✅ Fetch payment status for a booking
    Optional<Payment> findByBooking(Booking booking);

    // ✅ User-specific payment history
    List<Payment> findByBooking_User(User user);
}


