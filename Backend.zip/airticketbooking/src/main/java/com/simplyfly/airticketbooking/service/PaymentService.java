package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.PaymentRequest;
import com.simplyfly.airticketbooking.dto.PaymentResponse;

import java.util.List;

public interface PaymentService {

    // 💳 Make a new payment
    PaymentResponse makePayment(PaymentRequest request);

    // 📄 Get payment history for a user (used in /api/payments/my)
    List<PaymentResponse> getPaymentsForUser(String email);
    
    // Admin
    List<PaymentResponse> getAllPayments();
    
    //Retry payment
    PaymentResponse retryPayment(Long bookingId);
    
    String refundPayment(Long bookingId, String ownerEmail);


}
