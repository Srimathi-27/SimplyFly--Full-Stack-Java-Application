package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.AuthResponse;
import com.simplyfly.airticketbooking.dto.LoginRequest;
import com.simplyfly.airticketbooking.dto.RegisterRequest;
import com.simplyfly.airticketbooking.dto.ResetPasswordRequest;
import com.simplyfly.airticketbooking.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest request) {
        log.info("POST /api/auth/register called for email: {}", request.getEmail());
        AuthResponse response = userService.registerUser(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        log.info("POST /api/auth/login called for email: {}", request.getEmail());
        AuthResponse response = userService.authenticateUser(request);
        return ResponseEntity.ok(response);
    }
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestParam String email) {
        log.info("POST /api/auth/forgot-password called for email: {}", email);
        String resetLink = userService.generateResetLink(email); // custom method
        return resetLink != null
            ? ResponseEntity.ok(resetLink)
            : ResponseEntity.badRequest().body("Email not found.");
    }

    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest request) {
        log.info("POST /api/auth/reset-password called");
        boolean result = userService.resetPassword(request.getToken(), request.getNewPassword());
        return result
            ? ResponseEntity.ok("Password successfully updated.")
            : ResponseEntity.badRequest().body("Invalid or expired token.");
    }


}
