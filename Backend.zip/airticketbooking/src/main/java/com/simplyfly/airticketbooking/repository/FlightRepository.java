package com.simplyfly.airticketbooking.repository;

import com.simplyfly.airticketbooking.entity.Flight;
import com.simplyfly.airticketbooking.entity.Route;
import com.simplyfly.airticketbooking.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface FlightRepository extends JpaRepository<Flight, Long> {
    List<Flight> findByRouteAndDepartureTimeBetween(Route route, LocalDateTime start, LocalDateTime end);
    List<Flight> findByRoute_OriginAndRoute_DestinationAndDepartureTimeBetween(
    	    String origin, String destination, LocalDateTime start, LocalDateTime end);
    List<Flight> findByFlightOwner(User owner);
    boolean existsByRoute(Route route);
    
    @Query("SELECT DISTINCT f.route.origin FROM Flight f")
    List<String> findDistinctOrigins();

    @Query("SELECT DISTINCT f.route.destination FROM Flight f")
    List<String> findDistinctDestinations();


}

