package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.BookingRequest;
import com.simplyfly.airticketbooking.dto.BookingResponse;
import org.springframework.security.core.Authentication;

import java.util.List;

public interface BookingService {
    BookingResponse bookFlight(BookingRequest request, Authentication authentication);
    List<BookingResponse> getMyBookings(Authentication authentication);
    String cancelBooking(Long bookingId, Authentication authentication);
    List<BookingResponse> getAllBookings();
    List<BookingResponse> getBookingsForFlightOwner(String email);
    
}