package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import com.simplyfly.airticketbooking.dto.PasswordChangeRequest;
import com.simplyfly.airticketbooking.dto.UpdateUserRequest;
import java.util.*;

@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // Admin: View all users
    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<List<User>> getAllUsers() {
        log.info("GET /api/users - admin view all");
        return ResponseEntity.ok(userService.getAllUsers());
    }

    // Admin: Get user by ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        log.info("GET /api/users/{} - admin fetch user", id);
        return ResponseEntity.ok(userService.getUserById(id));
    }

    // Admin: Delete user
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable Long id) {
        log.info("DELETE /api/users/{} - admin delete user", id);
        userService.deleteUser(id);

        Map<String, String> response = new HashMap<>();
        response.put("message", "User deleted successfully");

        return ResponseEntity.ok(response);
    }


    // User: View own profile
    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<User> getCurrentUser(Authentication authentication) {
        String email = authentication.getName();
        log.info("GET /api/users/me - user: {}", email);
        return ResponseEntity.ok(userService.getCurrentUser(email));
    }

    // User: Update own profile
    @PutMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<User> updateCurrentUser(@Valid @RequestBody UpdateUserRequest request,
                                                  Authentication authentication) {
        String email = authentication.getName();
        log.info("PUT /api/users/me - updating user: {}", email);
        return ResponseEntity.ok(userService.updateCurrentUser(email, request));
    }
    
    @PutMapping("/change-password")
    @PreAuthorize("hasAnyRole('ROLE_USER', 'ROLE_ADMIN', 'ROLE_FLIGHT_OWNER')")
    public ResponseEntity<Map<String, String>> changePassword(
            @RequestBody PasswordChangeRequest request,
            Authentication authentication) {

        String email = authentication.getName();
        userService.changePassword(email, request.getCurrentPassword(), request.getNewPassword());

        // ✅ Return a structured JSON response
        Map<String, String> response = new HashMap<>();
        response.put("message", "Password updated successfully.");

        return ResponseEntity.ok(response);
    }


}
