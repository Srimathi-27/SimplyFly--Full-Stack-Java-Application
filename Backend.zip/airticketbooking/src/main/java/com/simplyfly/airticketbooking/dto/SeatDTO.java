package com.simplyfly.airticketbooking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.simplyfly.airticketbooking.enums.SeatClass;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SeatDTO {
    private Long id;
    private String seatNumber;
    private boolean booked;
    private SeatClass seatClass;
    private String status; 

}
