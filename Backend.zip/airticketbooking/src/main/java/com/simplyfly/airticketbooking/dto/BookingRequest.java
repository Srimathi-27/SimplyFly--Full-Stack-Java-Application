package com.simplyfly.airticketbooking.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequest {
    
    @NotNull(message = "Flight ID is required")
    private Long flightId;

    @Min(value = 1, message = "At least 1 seat must be booked")
    private int seatCount;

    @NotEmpty(message = "Seat numbers must be provided")
    private List<String> seatNumbers;  // Custom seat selection
}

