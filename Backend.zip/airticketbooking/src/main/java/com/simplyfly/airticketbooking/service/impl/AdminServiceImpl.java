package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.DashboardStatsResponse;
import com.simplyfly.airticketbooking.enums.Role;
import com.simplyfly.airticketbooking.repository.*;
import com.simplyfly.airticketbooking.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final FlightRepository flightRepository;
    private final BookingRepository bookingRepository;
    private final RouteRepository routeRepository;
    private final PaymentRepository paymentRepository;

    @Override
    public DashboardStatsResponse getDashboardStats() {
        long totalUsers = userRepository.countByRole(Role.USER);
        long totalFlightOwners = userRepository.countByRole(Role.FLIGHT_OWNER);
        long totalFlights = flightRepository.count();
        long totalBookings = bookingRepository.count();
        long totalRoutes = routeRepository.count();
        long totalPayments = paymentRepository.count();

        return new DashboardStatsResponse(
            totalUsers,
            totalFlightOwners,
            totalFlights,
            totalBookings,
            totalRoutes,
            totalPayments
        );
    }
}
