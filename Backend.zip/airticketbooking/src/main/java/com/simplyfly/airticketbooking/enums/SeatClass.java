package com.simplyfly.airticketbooking.enums;

public enum SeatClass {
    ECONOMY,
    BUSINESS
}

