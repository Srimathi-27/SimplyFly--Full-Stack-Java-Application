package com.simplyfly.airticketbooking.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BookingResponse {

    private Long bookingId;
    private String flightNumber;
    private String flightName;
    private String origin;
    private String destination;
    private int seatCount;
    private double totalPrice;
    private String status;
    private LocalDateTime bookingDate;

    private List<String> bookedSeatNumbers;

    private String paymentStatus; // ✅ Corrected spelling
}
