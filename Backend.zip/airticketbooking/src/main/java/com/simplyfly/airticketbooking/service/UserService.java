package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.AuthResponse;
import com.simplyfly.airticketbooking.dto.LoginRequest;
import com.simplyfly.airticketbooking.dto.PasswordChangeRequest;
import com.simplyfly.airticketbooking.dto.RegisterRequest;
import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.dto.UpdateUserRequest;

import java.util.List;

public interface UserService {

    // 🔐 Auth
    AuthResponse registerUser(RegisterRequest request);
    AuthResponse authenticateUser(LoginRequest request);

    // 👤 User management
    User getCurrentUser(String email);
    User updateCurrentUser(String email, UpdateUserRequest request);
    void changePassword(String email, String currentPassword, String newPassword);


    // 🛠️ Admin management
    List<User> getAllUsers();
    User getUserById(Long id);
    void deleteUser(Long id);
    
    String generateResetLink(String email);
    boolean resetPassword(String token, String newPassword);


}
