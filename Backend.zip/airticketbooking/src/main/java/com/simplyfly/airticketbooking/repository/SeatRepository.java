package com.simplyfly.airticketbooking.repository;

import com.simplyfly.airticketbooking.entity.Flight;
import com.simplyfly.airticketbooking.entity.Seat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SeatRepository extends JpaRepository<Seat, Long> {

    // Get all unbooked seats for a specific flight
    List<Seat> findByFlightAndIsBookedFalse(Flight flight);

    // Get all seats by booking ID
    List<Seat> findByBookingId(Long bookingId);

    // Get all seats (booked + unbooked) by flight
    List<Seat> findByFlight(Flight flight);

    // Get only available seats by flight ID
    List<Seat> findByFlightIdAndIsBookedFalse(Long flightId);

    // Optional: Get all seats by flight ID
    List<Seat> findByFlightId(Long flightId);
}

