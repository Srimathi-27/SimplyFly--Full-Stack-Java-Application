package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.PaymentRequest;
import com.simplyfly.airticketbooking.dto.PaymentResponse;
import com.simplyfly.airticketbooking.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    // 🔘 Make a new payment
    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<PaymentResponse> makePayment(@Valid @RequestBody PaymentRequest request) {
        log.info("POST /api/payments - Processing payment for booking {}", request.getBookingId());
        PaymentResponse response = paymentService.makePayment(request);
        return ResponseEntity.ok(response);
    }

    // 📄 Get user's payment history
    @GetMapping("/my")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<List<PaymentResponse>> getMyPayments(Authentication authentication) {
        String email = authentication.getName();
        log.info("GET /api/payments/my - Fetching payments for user: {}", email);
        return ResponseEntity.ok(paymentService.getPaymentsForUser(email));
    }
 // 📄 Admin: View all payments
    @GetMapping("/all")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<List<PaymentResponse>> getAllPayments() {
        log.info("GET /api/payments/all - Admin requested all payments");
        return ResponseEntity.ok(paymentService.getAllPayments());
    }
    // Retry payment
    @PutMapping("/retry/{bookingId}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<PaymentResponse> retryPayment(@PathVariable Long bookingId) {
        log.info("PUT /api/payments/retry/{} - Retrying payment", bookingId);
        PaymentResponse response = paymentService.retryPayment(bookingId);
        return ResponseEntity.ok(response);
    }
    @PostMapping("/refund/{bookingId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_FLIGHT_OWNER')")
    public ResponseEntity<String> refundBooking(@PathVariable Long bookingId, Authentication authentication) {
        String email = authentication.getName();
        return ResponseEntity.ok(paymentService.refundPayment(bookingId, email));
    }



}
