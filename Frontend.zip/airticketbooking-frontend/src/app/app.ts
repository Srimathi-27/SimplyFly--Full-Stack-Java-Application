import { Component } from '@angular/core';
import { AuthService } from './shared/services/auth';
import { jwtDecode } from 'jwt-decode';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.scss'
})
export class App {
  protected title = 'airticketbooking-frontend';
  activeNavbar: 'user' | 'owner' | 'admin' | 'public' = 'public';

  constructor(private router: Router) {
    router.events.subscribe(() => {
      const path = this.router.url;

      // Show public navbar for public-facing pages including root
      if (
        path === '/' ||
        path.startsWith('/auth') ||
        path.includes('/auth/login') ||
        path.includes('/auth/register') ||
        path.includes('/auth/forgot-password') ||
        path.includes('/auth/reset-password')
      ) {
        this.activeNavbar = 'public';
        return;
      }


      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded: any = jwtDecode(token);
          const role = decoded.role;
          if (role === 'ROLE_USER') this.activeNavbar = 'user';
          else if (role === 'ROLE_FLIGHT_OWNER') this.activeNavbar = 'owner';
          else if (role === 'ROLE_ADMIN') this.activeNavbar = 'admin';
          else this.activeNavbar = 'public';
        } catch {
          this.activeNavbar = 'public';
        }
      } else {
        this.activeNavbar = 'public';
      }
    });
  }
}
