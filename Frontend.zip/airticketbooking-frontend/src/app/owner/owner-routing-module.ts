import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { roleGuard } from '../shared/guards/role-guard';
//import { Dashboard } from './dashboard/dashboard';
import { Dashboard } from '../owner/dashboard/dashboard';
import { Flights } from './flights/flights';
import { FlightForm } from './flight-form/flight-form';
import { Bookings } from './bookings/bookings';
import { Seats } from './seats/seats';

const routes: Routes = [
  {
    path: '',
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_FLIGHT_OWNER' },
    children: [
      { path: 'dashboard', component: Dashboard },
      { path: 'flights', component: Flights }, 
      { path: 'flights/add', component: FlightForm },
      { path: 'flights/edit/:id', component: FlightForm },
      { path: 'bookings', component: Bookings },
      { path: 'seats', component: Seats},

      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OwnerRoutingModule { }
