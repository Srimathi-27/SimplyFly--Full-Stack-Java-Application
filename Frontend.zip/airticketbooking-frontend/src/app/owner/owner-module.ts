import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OwnerRoutingModule } from './owner-routing-module';
import { Dashboard } from './dashboard/dashboard';

import { Flights } from './flights/flights';
import { FlightForm } from './flight-form/flight-form';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Bookings } from './bookings/bookings';
import { Seats } from './seats/seats';


@NgModule({
  declarations: [
    Dashboard,
    Flights,
    FlightForm,
    Bookings,
    Seats
  ],
  imports: [
    CommonModule,
    OwnerRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class OwnerModule { }
