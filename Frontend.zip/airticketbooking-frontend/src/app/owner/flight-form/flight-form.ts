import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Flight, OwnerService } from '../services/owner.service';
import { AlertService } from '../../shared/services/alert.service';


@Component({
  selector: 'app-flight-form',
  standalone: false,
  templateUrl: './flight-form.html',
  styleUrl: './flight-form.scss'
})
export class FlightForm implements OnInit {
  flightForm!: FormGroup;
  isEditMode = false;
  flightId!: number;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private ownerService: OwnerService,
    private router: Router,
    private alertService: AlertService 
  ) {}

  ngOnInit(): void {
    this.flightId = Number(this.route.snapshot.paramMap.get('id'));
    this.isEditMode = !!this.flightId;

    this.flightForm = this.fb.group({
      flightNumber: ['', Validators.required],
      flightName: ['', Validators.required],
      routeId: [null, Validators.required],
      fare: [0, [Validators.required, Validators.min(1)]],
      totalSeats: [0, [Validators.required, Validators.min(1)]],
      baggageCheckin: ['', Validators.required],
      baggageCabin: ['', Validators.required],
      departureTime: ['', Validators.required],
      arrivalTime: ['', Validators.required]
    });

    if (this.isEditMode) {
      this.ownerService.getFlightById(this.flightId).subscribe({
        next: (flight: Flight) => {
          this.flightForm.patchValue(flight);
        },
        error: (err) => {
          this.errorMessage = 'Failed to load flight data.';
          this.alertService.error(this.errorMessage); 
          console.error(err);
        }
      });
    }
  }

  submit(): void {
    if (this.flightForm.invalid) return;

    const flightData: Flight = this.flightForm.value;

    if (this.isEditMode) {
      this.ownerService.updateFlight(this.flightId, flightData).subscribe({
        next: () => {
          this.alertService.success('Flight updated successfully ✅');
          setTimeout(() => this.router.navigate(['/owner/flights']), 1500);
        },
        error: (err) => {
          this.errorMessage = 'Failed to update flight.';
          this.alertService.error(this.errorMessage); 
          console.error(err);
        }
      });
    } else {
      this.ownerService.addFlight(flightData).subscribe({
        next: () => {
          this.alertService.success('Flight added successfully ✅');
          this.flightForm.reset();
          setTimeout(() => this.router.navigate(['/owner/flights']), 1500);
        },
        error: (err) => {
          this.errorMessage = 'Failed to add flight.';
          this.alertService.error(this.errorMessage); 
          console.error(err);
        }
      });
    }
  }

  cancel(): void {
    this.router.navigate(['/owner/flights']);
  }
}
