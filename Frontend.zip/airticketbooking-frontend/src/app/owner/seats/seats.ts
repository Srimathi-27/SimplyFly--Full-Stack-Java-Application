import { Component, OnInit } from '@angular/core';
import { Flight, OwnerService, Seat } from '../services/owner.service';

@Component({
  selector: 'app-seats',
  standalone: false,
  templateUrl: './seats.html',
  styleUrl: './seats.scss'
})
export class Seats implements OnInit {
  flights: Flight[] = [];
  seats: Seat[] = [];
  selectedFlightId: number | null = null;
  isLoading = false;
  errorMessage = '';

  constructor(private ownerService: OwnerService) {}

  ngOnInit(): void {
    this.ownerService.getMyFlights().subscribe({
      next: (data) => (this.flights = data),
      error: (err) => console.error('Failed to load flights', err)
    });
  }

  loadSeats(): void {
    if (!this.selectedFlightId) return;
    this.isLoading = true;
    this.seats = [];

    this.ownerService.getSeatsByFlight(this.selectedFlightId).subscribe({
      next: (data) => {
        console.log('✅ Total seats loaded:', data.length); 
        this.seats = data;
        this.isLoading = false;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load seats.';
        this.isLoading = false;
      }
    });
  }
  toggleSeatStatus(seat: any): void {
    const action = seat.status === 'BLOCKED' ? 'unblockSeat' : 'blockSeat';

    this.ownerService[action](seat.id).subscribe({
      next: () => this.loadSeats(),
      error: (err) => console.error('Seat toggle failed', err)
    });
  }
}
