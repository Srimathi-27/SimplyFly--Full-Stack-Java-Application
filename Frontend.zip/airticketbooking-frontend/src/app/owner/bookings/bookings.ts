import { Component, OnInit } from '@angular/core';
import { Booking, OwnerService } from '../services/owner.service';

@Component({
  selector: 'app-bookings',
  standalone: false,
  templateUrl: './bookings.html',
  styleUrl: './bookings.scss'
})
export class Bookings implements OnInit {
  bookings: Booking[] = [];
  isLoading = true;
  errorMessage = '';

  constructor(private ownerService: OwnerService) {}

  ngOnInit(): void {
    this.loadBookings();
  }

  // ✅ Centralized method to fetch bookings (used on init and after refund)
  loadBookings(): void {
    this.isLoading = true;
    this.ownerService.getMyBookings().subscribe({
      next: (data) => {
        this.bookings = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to load bookings', err);
        this.errorMessage = 'Could not load bookings.';
        this.isLoading = false;
      }
    });
  }

  canRefund(booking: Booking): boolean {
    return booking.status === 'CANCELLED' && booking.paymentStatus === 'PAID';
  }

  refund(bookingId: number): void {
    if (!confirm('Are you sure you want to refund this booking?')) return;

    this.ownerService.refundBooking(bookingId).subscribe({
      next: (msg) => {
        alert(msg);
        this.loadBookings(); 
      },
      error: (err) => {
        console.error('❌ Refund failed', err);
        alert('Refund failed. Please try again later.');
      }
    });
  }

}
