import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Flight, OwnerService } from '../services/owner.service';

@Component({
  selector: 'app-flights',
  standalone: false,
  templateUrl: './flights.html',
  styleUrls: ['./flights.scss']
})
export class Flights implements OnInit {
  flights: Flight[] = [];
  isLoading = true;
  errorMessage = '';

  constructor(private ownerService: OwnerService, private router: Router) {}

  ngOnInit(): void {
    this.loadFlights();
  }

  loadFlights(): void {
    this.isLoading = true;
    this.ownerService.getMyFlights().subscribe({
      next: (data) => {
        if (Array.isArray(data)) {
          this.flights = data.map(flight => ({
            ...flight,
            departureTime: new Date(flight.departureTime),
            arrivalTime: new Date(flight.arrivalTime)
          }));
        } else {
          console.warn('Expected an array of flights but got:', data);
          this.flights = [];
        }
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching flights', err);
        this.errorMessage = 'Failed to load flights';
        this.isLoading = false;
      }
    });
  }

  addFlight(): void {
    this.router.navigate(['/owner/flights/add']);
  }

  editFlight(id: number): void {
    this.router.navigate(['/owner/flights/edit', id]);
  }

  deleteFlight(id: number): void {
    if (confirm('Are you sure you want to delete this flight?')) {
      this.ownerService.deleteFlight(id).subscribe({
        next: () => {
          alert('Flight deleted successfully');
          this.loadFlights();
        },
        error: (err) => {
          console.error('Delete flight failed', err);
          alert('Failed to delete flight. Please try again.');
        }
      });
    }
  }
}
