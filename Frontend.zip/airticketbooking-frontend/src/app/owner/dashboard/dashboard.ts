import { Component, OnInit } from '@angular/core';
import { OwnerService, Booking } from '../services/owner.service';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard implements OnInit {
  isLoading = true;
  errorMessage = '';

  totalFlights = 0;
  totalSeats = 0;
  totalBookings = 0;
  totalRevenue = 0;

  constructor(private ownerService: OwnerService) {}

  ngOnInit(): void {
    // First: Load flights
    this.ownerService.getMyFlights().subscribe({
      next: (flights) => {
        this.totalFlights = flights.length;
        this.totalSeats = flights.reduce((sum, f) => sum + f.totalSeats, 0);

        // Then: Load bookings
        this.ownerService.getMyBookings().subscribe({
          next: (bookings: Booking[]) => {
            this.totalBookings = bookings.length;
            this.totalRevenue = bookings
              .filter(b => b.paymentStatus === 'PAID') // only count successful payments
              .reduce((sum, b) => sum + b.totalPrice, 0);
            this.isLoading = false;
          },
          error: (err) => {
            console.error('Failed to load bookings', err);
            this.errorMessage = 'Failed to load bookings.';
            this.isLoading = false;
          }
        });
      },
      error: (err) => {
        this.errorMessage = 'Failed to load flight data.';
        console.error(err);
        this.isLoading = false;
      }
    });
  }
}