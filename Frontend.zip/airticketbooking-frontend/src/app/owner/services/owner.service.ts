import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Flight {
  id: number;
  flightNumber: string;
  flightName: string;
  origin: string;
  destination: string;
  routeId: number;
  fare: number;
  totalSeats: number;
  baggageCheckin: string;
  baggageCabin: string;
  departureTime: string | Date;
  arrivalTime: string | Date;
  flightOwnerEmail: string;
}

export interface Booking {
  bookingId: number;
  flightNumber: string;
  flightName: string;
  origin: string;
  destination: string;
  totalPrice: number;
  bookedSeatNumbers: string[];
  seatCount: number;
  status: string;
  paymentStatus: string;
  bookingDate: string;
}
export interface Seat {
  id: number;
  seatNumber: string;
  booked: boolean;
  seatClass: 'ECONOMY' | 'BUSINESS';
  status: string;
}


@Injectable({ providedIn: 'root' })
export class OwnerService {
  private baseFlightUrl = 'http://localhost:8081/api/flights';
  private baseBookingUrl = 'http://localhost:8081/api/bookings';

  constructor(private http: HttpClient) {}

  // 🛫 Get all flights added by this flight owner
  getMyFlights(): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.baseFlightUrl}/owner`);
  }

  getMyBookings(): Observable<Booking[]> {
  return this.http.get<Booking[]>(`http://localhost:8081/api/bookings/owner`);
}


  addFlight(flight: Flight): Observable<string> {
  return this.http.post(`${this.baseFlightUrl}`, flight, { responseType: 'text' });
}

updateFlight(id: number, flight: Flight): Observable<string> {
  return this.http.put(`${this.baseFlightUrl}/${id}`, flight, { responseType: 'text' });
}

deleteFlight(id: number): Observable<string> {
  return this.http.delete(`${this.baseFlightUrl}/${id}`, { responseType: 'text' });
}
getFlightById(id: number): Observable<Flight> {
  return this.http.get<Flight>(`${this.baseFlightUrl}/${id}`);
}
  // 🪑 Optional: You can also create endpoints for owner to fetch grouped/available seats
  getSeatsByFlight(flightId: number): Observable<Seat[]> {
  return this.http.get<Seat[]>(`http://localhost:8081/api/seats/flight/${flightId}/all`);
}
blockSeat(seatId: number): Observable<string> {
  return this.http.put(`http://localhost:8081/api/seats/${seatId}/block`, null, {
    responseType: 'text'
  });
}

unblockSeat(seatId: number): Observable<string> {
  return this.http.put(`http://localhost:8081/api/seats/${seatId}/unblock`, null, {
    responseType: 'text'
  });
}
refundBooking(bookingId: number): Observable<string> {
  return this.http.post(`http://localhost:8081/api/payments/refund/${bookingId}`, null, {
    responseType: 'text'
  });
}



}

