import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../shared/services/auth';

@Component({
  selector: 'app-forgot-password',
  standalone: false,
  templateUrl: './forgot-password.html',
  styleUrl: './forgot-password.scss'
})
export class ForgotPassword {
  form: FormGroup;
  message = '';
  error = '';
  resetUrl = '';  

  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  onSubmit(): void {
  if (this.form.valid) {
    this.authService.forgotPassword(this.form.value.email).subscribe({
      next: (res) => {
        this.resetUrl = res; 
        this.message = 'Reset link is ready. Click the button below.';
        this.error = '';
      },
      error: (err) => {
        this.error = typeof err.error === 'string'
          ? err.error
          : err.error?.message || 'Failed to send reset link.';
        this.message = '';
        this.resetUrl = '';
      }
    });
  }
}


}
