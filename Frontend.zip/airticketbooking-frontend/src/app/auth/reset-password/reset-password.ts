import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router'; // ✅ Add Router
import { AuthService } from '../../shared/services/auth';

@Component({
  selector: 'app-reset-password',
  standalone: false,
  templateUrl: './reset-password.html',
  styleUrls: ['./reset-password.scss']
})
export class ResetPassword implements OnInit {
  form: FormGroup;
  token = '';
  message = '';
  error = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router, // ✅ Inject Router
    private authService: AuthService
  ) {
    this.form = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    const tokenParam = this.route.snapshot.queryParamMap.get('token');
    if (tokenParam) {
      this.token = tokenParam;
    } else {
      this.error = 'Invalid or missing token.';
    }
  }

  onSubmit(): void {
    if (this.form.valid && this.token) {
      const newPassword = this.form.value.newPassword;

      this.authService.resetPassword(this.token, newPassword).subscribe({
        next: (res: string) => {
          this.message = res;
          this.error = '';

          // ✅ Redirect to login page after 3 seconds
          setTimeout(() => {
            this.router.navigate(['/auth/login']);
          }, 3000);
        },
        error: (err) => {
          this.error = typeof err.error === 'string'
            ? err.error
            : err.error?.message || 'Failed to reset password.';
          this.message = '';
        }
      });
    }
  }
}
