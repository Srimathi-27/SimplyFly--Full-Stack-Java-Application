import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../shared/services/auth';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';
import { AlertService } from '../../shared/services/alert.service';


@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrl: './login.scss'
})
export class Login {
  form: FormGroup;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private alert: AlertService 
  ) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
  if (this.form.valid) {
    const data = this.form.value;

    this.authService.login(data).subscribe({
      next: async (res) => {
        this.authService.storeToken(res.token);

        const decodedToken: any = jwtDecode(res.token);
        const role = decodedToken?.role;

        // ✅ Wait for user to close the alert before navigating
        await this.alert.success('Welcome back!', 'Login Successful');

        this.navigateBasedOnRole(role);
      },
      error: () => {
        this.errorMessage = 'Invalid email or password';
        this.alert.error(this.errorMessage, 'Login Failed');
      }
    });
  }
}

  private navigateBasedOnRole(role: string): void {
    switch (role) {
      case 'ROLE_USER':
        this.router.navigate(['/user/dashboard']);
        break;
      case 'ROLE_FLIGHT_OWNER':
        this.router.navigate(['/owner/dashboard']);
        break;
      case 'ROLE_ADMIN':
        this.router.navigate(['/admin/dashboard']);
        break;
      default:
        this.router.navigate(['/auth/login']);
    }
  }
}
