import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Landing } from './landing/landing';

const routes: Routes = [
  { path: '', component: Landing }, //  Landing Page as default
  { path: 'auth', loadChildren: () => import('./auth/auth-module').then(m => m.AuthModule) },
  { path: 'owner', loadChildren: () => import('./owner/owner-module').then(m => m.OwnerModule) },
  { path: 'user', loadChildren: () => import('./user/user-module').then(m => m.UserModule) },
  { path: 'admin', loadChildren: () => import('./admin/admin-module').then(m => m.AdminModule) },
  { path: '**', redirectTo: '' } //  Redirect unknown paths to landing
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
