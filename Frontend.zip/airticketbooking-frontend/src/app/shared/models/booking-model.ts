export interface BookingRequest {
  flightId: number;
  seatCount: number;
  seatNumbers: string[];
}

export interface BookingResponse {
  bookingId: number;
  flightNumber: string;
  flightName: string;
  origin: string;
  destination: string;
  seatCount: number;
  totalPrice: number;
  status: string;
  bookingDate: string;
  bookedSeatNumbers: string[];
  paymentStatus: string;
}
