export interface Flight {
  id?: number;
  flightNumber: string;
  flightName: string;
  origin: string;
  destination: string;
  fare: number;
  totalSeats: number;
  baggageCheckin: string;
  baggageCabin: string;
  departureTime: string;
  arrivalTime: string;
  flightOwnerEmail?: string;
}
