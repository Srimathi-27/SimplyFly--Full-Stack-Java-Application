export interface SeatDTO {
  id: number;
  seatNumber: string;
  booked: boolean;
  seatClass: 'ECONOMY' | 'BUSINESS';
  row?: number;
  column?: string;
  status: string;

}
