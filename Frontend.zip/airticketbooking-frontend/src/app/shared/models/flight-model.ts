export interface FlightSearchRequest {
  origin: string;
  destination: string;
  departureDate: string; // yyyy-MM-dd
}

export interface FlightResponse {
  id: number;
  flightNumber: string;
  flightName: string;
  origin: string;
  destination: string;
  fare: number;
  totalSeats: number;
  baggageCheckin: string;
  baggageCabin: string;
  departureTime: string;
  arrivalTime: string;
  flightOwnerEmail: string;
}
