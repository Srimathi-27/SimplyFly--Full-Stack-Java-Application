export interface PaymentRequest {
  bookingId: number;
  paymentMethod: string;
}

export interface PaymentResponse {
  paymentId: number;
  status: string;
  amount: number;
  message: string;
}
