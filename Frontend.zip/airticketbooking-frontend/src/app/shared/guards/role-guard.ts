import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../../shared/services/auth';
import { jwtDecode } from 'jwt-decode';

export const roleGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  const token = authService.getToken();
  if (!token) {
    router.navigate(['/auth/login']);
    return false;
  }

  try {
    const decoded: any = jwtDecode(token);
    const userRole = decoded?.role;
    const expectedRole = route.data['expectedRole'];

    if (userRole === expectedRole) {
      return true;
    } else {
      router.navigate(['/auth/login']);
      return false;
    }
  } catch (err) {
    console.error('❌ Invalid token:', err);
    router.navigate(['/auth/login']);
    return false;
  }
};

