import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { jwtDecode } from 'jwt-decode';
import { UserService } from '../../services/user';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-user-navbar',
  standalone: false,
  templateUrl: './user-navbar.html',
  styleUrl: './user-navbar.scss'
})
export class UserNavbar implements OnInit {
  username: string = 'User';

  constructor(
    private auth: AuthService,
    private userService: UserService,
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    const token = this.auth.getToken();

    if (token) {
      // Try fetching name from backend
      this.userService.getCurrentUser().subscribe({
        next: (user) => {
          this.username = user.name || 'User';
        },
        error: (err) => {
          console.warn('Failed to fetch user profile:', err);

          // fallback to decoded token
          try {
            const decoded: any = jwtDecode(token);
            this.username = decoded.sub?.split('@')[0] || 'User';
          } catch (decodeErr) {
            console.warn('JWT Decode Fallback Failed:', decodeErr);
          }
        }
      });
    }
  }

  logout(): void {
  this.alertService.confirm('You will be logged out. Continue?', 'Confirm Logout')
    .then((result) => {
      if (result.isConfirmed) {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
        this.alertService.toast('Logged out successfully.', 'success');
      }
    });
}

}
