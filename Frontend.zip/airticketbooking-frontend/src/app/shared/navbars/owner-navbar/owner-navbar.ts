import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';
import { UserService } from '../../services/user';
import { AlertService } from '../../services/alert.service';


@Component({
  selector: 'app-owner-navbar',
  standalone: false,
  templateUrl: './owner-navbar.html',
  styleUrl: './owner-navbar.scss'
})
export class OwnerNavbar implements OnInit {
  username: string = 'Owner';

  constructor(
    private auth: AuthService,
    private userService: UserService,
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    const token = this.auth.getToken();

    if (token) {
      // First try to get the actual user name from backend
      this.userService.getCurrentUser().subscribe({
        next: (user) => {
          this.username = user.name || 'Owner';
        },
        error: (err) => {
          console.warn('❌ Could not fetch user profile, falling back to JWT:', err);
          try {
            const decoded: any = jwtDecode(token);
            this.username = decoded.sub?.split('@')[0] || 'Owner';
          } catch (decodeErr) {
            console.warn('JWT Decode Fallback Failed:', decodeErr);
          }
        }
      });
    }
  }

  logout(): void {
  this.alertService.confirm('You will be logged out. Continue?', 'Confirm Logout')
    .then((result) => {
      if (result.isConfirmed) {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
        this.alertService.toast('Logged out successfully.', 'success');
      }
    });
}

}
