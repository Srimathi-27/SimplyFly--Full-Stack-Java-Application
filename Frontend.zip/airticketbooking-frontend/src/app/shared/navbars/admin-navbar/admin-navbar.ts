import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';
import { UserService } from '../../services/user';
import { AlertService } from '../../services/alert.service';


@Component({
  selector: 'app-admin-navbar',
  standalone: false,
  templateUrl: './admin-navbar.html',
  styleUrl: './admin-navbar.scss'
})
export class AdminNavbar implements OnInit {
  username: string = 'Admin';

  constructor(
    private auth: AuthService,
    private userService: UserService,
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    const token = this.auth.getToken();

    if (token) {
      this.userService.getCurrentUser().subscribe({
        next: (user) => {
          this.username = user.name || 'Admin';
        },
        error: (err) => {
          console.warn('⚠️ Could not fetch admin name from backend:', err);
          try {
            const decoded: any = jwtDecode(token);
            this.username = decoded.sub?.split('@')[0] || 'Admin';
          } catch (decodeErr) {
            console.warn('JWT decode fallback failed:', decodeErr);
          }
        }
      });
    }
  }

  logout(): void {
  this.alertService.confirm('You will be logged out. Continue?', 'Confirm Logout')
    .then((result) => {
      if (result.isConfirmed) {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
        this.alertService.toast('Logged out successfully.', 'success');
      }
    });
}
}
