import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SeatDTO } from '../models/seat-model';

@Injectable({
  providedIn: 'root'
})
export class SeatService {
  private baseUrl = 'http://localhost:8081/api/seats';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({ Authorization: `Bearer ${token}` });
  }

  getGroupedSeats(flightId: number): Observable<Record<string, SeatDTO[]>> {
    return this.http.get<Record<string, SeatDTO[]>>(
      `${this.baseUrl}/flight/${flightId}/grouped?onlyAvailable=false`,
      { headers: this.getHeaders() }
    );
  }
}
