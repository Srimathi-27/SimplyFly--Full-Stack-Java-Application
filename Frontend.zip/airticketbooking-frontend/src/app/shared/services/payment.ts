import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PaymentRequest, PaymentResponse } from '../models/payment-model'; // ✅ Confirm path

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private baseUrl = 'http://localhost:8081/api/payments';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  /**
   * ✅ Make a payment
   */
  makePayment(request: PaymentRequest): Observable<PaymentResponse> {
    return this.http.post<PaymentResponse>(this.baseUrl, request, {
      headers: this.getHeaders()
    });
  }

  /**
   * 📄 Get current user's payments
   */
  getUserPayments(): Observable<PaymentResponse[]> {
    return this.http.get<PaymentResponse[]>(`${this.baseUrl}/my`, {
      headers: this.getHeaders()
    });
  }

  /**
   * 🔁 Retry a failed payment
   */
  retryPayment(bookingId: number): Observable<PaymentResponse> {
    return this.http.put<PaymentResponse>(`${this.baseUrl}/retry/${bookingId}`, null, {
      headers: this.getHeaders()
    });
  }
}
