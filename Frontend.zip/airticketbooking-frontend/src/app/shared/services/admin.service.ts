import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

// 📊 Dashboard Interface
export interface DashboardStats {
  users: number;
  flightOwners: number;
  flights: number;
  bookings: number;
  routes: number;
  payments: number;
}

// 👤 User Interface
export interface User {
  id: number;
  name: string;
  email: string;
  role: 'ROLE_USER' | 'ROLE_FLIGHT_OWNER' | 'ROLE_ADMIN';
}

// ✈️ Flight Interfaces
export interface Flight {
  id: number;
  flightNumber: string;
  flightName: string;
  routeId: number;
  origin: string;
  destination: string;
  fare: number;
  totalSeats: number;
  baggageCheckin: string;
  baggageCabin: string;
  departureTime: string; // ISO string
  arrivalTime: string;   // ISO string
  flightOwnerEmail?: string;
}

export interface AddFlightRequest {
  flightNumber: string;
  flightName: string;
  routeId: number;
  totalSeats: number;
  fare: number;
  baggageCheckin: string;
  baggageCabin: string;
  departureTime: string; // ISO string
  arrivalTime: string;   // ISO string
}

// 🔍 Flight search request
export interface FlightSearchRequest {
  origin: string;
  destination: string;
  departureDate: string; // Format: YYYY-MM-DD
}

// 🧭 Route Interface
export interface Route {
  id: number;
  origin: string;
  destination: string;
  distance: number;
}

// 📦 Booking Interface
export interface Booking {
  id: number;
  user: User;
  flightId: number;
  date: string;
  status: string;
}

// 💳 Payment Interface
export interface Payment {
  id: number;
  bookingId: number;
  amount: number;
  status: string;
  paymentDate: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private readonly baseUrl = 'http://localhost:8081/api';

  constructor(private http: HttpClient) {}

  // 📊 Dashboard
  getDashboardStats(): Observable<DashboardStats> {
  return this.http.get<DashboardStats>(`${this.baseUrl}/admin/dashboard-stats`, {
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
    }
  });
}

  // 👥 Users
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}/users`);
  }

  getAllFlightOwners(): Observable<User[]> {
    return this.getAllUsers().pipe(
      map(users => users.filter(u => u.role === 'ROLE_FLIGHT_OWNER'))
    );
  }

  deleteUser(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/users/${id}`, { responseType: 'text' });
  }

  getAuthenticatedUser(): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/auth/me`);
  }

  // ✈️ Flights
  getAllFlights(): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.baseUrl}/flights`);
  }

  getFlightById(id: number): Observable<Flight> {
    return this.http.get<Flight>(`${this.baseUrl}/flights/${id}`);
  }

  addFlight(payload: AddFlightRequest): Observable<string> {
    return this.http.post(`${this.baseUrl}/flights`, payload, { responseType: 'text' });
  }

  updateFlight(id: number, payload: AddFlightRequest): Observable<string> {
    return this.http.put(`${this.baseUrl}/flights/${id}`, payload, { responseType: 'text' });
  }

  deleteFlight(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/flights/${id}`, { responseType: 'text' });
  }

  getFlightsByOwner(): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.baseUrl}/flights/owner`);
  }

  searchFlights(payload: FlightSearchRequest): Observable<Flight[]> {
    return this.http.post<Flight[]>(`${this.baseUrl}/flights/search`, payload);
  }

  // 🧭 Routes
  getAllRoutes(): Observable<Route[]> {
    return this.http.get<Route[]>(`${this.baseUrl}/routes`);
  }

  // 📦 Bookings
  getAllBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.baseUrl}/bookings/all`);
  }

  // 💳 Payments
  getAllPayments(): Observable<Payment[]> {
    return this.http.get<Payment[]>(`${this.baseUrl}/payments/all`);
  }
}
