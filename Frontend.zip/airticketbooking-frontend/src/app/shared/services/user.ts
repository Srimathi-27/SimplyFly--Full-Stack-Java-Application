import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl = 'http://localhost:8081/api/users';

  constructor(private http: HttpClient) {}

  /**
   * Get the currently logged-in user's profile securely with token
   */
  getCurrentUser(): Observable<any> {
    const token = localStorage.getItem('token');

    if (!token) {
      console.warn('⚠️ No token found in localStorage');
    }

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token ?? ''}`
    });

    return this.http.get(`${this.baseUrl}/me`, { headers });
  }

  // Update user profile
  updateUserProfile(user: any): Observable<any> {
  const token = localStorage.getItem('token');
  const headers = new HttpHeaders({
    Authorization: `Bearer ${token}`
  });

  return this.http.put('http://localhost:8081/api/users/me', user, { headers });
}
changePassword(payload: { currentPassword: string; newPassword: string }) {
  const token = localStorage.getItem('token');
  const headers = new HttpHeaders({
    Authorization: `Bearer ${token}`
  });
  return this.http.put(`${this.baseUrl}/change-password`, payload, { headers });
}

}

