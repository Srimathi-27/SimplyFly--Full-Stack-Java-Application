import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BookingRequest, BookingResponse } from '../models/booking-model';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private baseUrl = 'http://localhost:8081/api/bookings';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  /**
   * 🔄 Get all bookings for the currently logged-in user
   */
  getUserBookings(): Observable<BookingResponse[]> {
    return this.http.get<BookingResponse[]>(`${this.baseUrl}/my`, {
      headers: this.getHeaders()
    });
  }

  /**
   * ❌ Cancel a specific booking
   */
  cancelBooking(bookingId: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/${bookingId}`, {
      headers: this.getHeaders(),
      responseType: 'text'
    });
  }

  /**
   * ✅ Book a flight using BookingRequest
   */
  bookFlight(request: BookingRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${this.baseUrl}`, request, {
      headers: this.getHeaders()
    });
  }
}
