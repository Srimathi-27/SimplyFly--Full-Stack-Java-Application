import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FlightResponse, FlightSearchRequest } from '../models/flight-model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private baseUrl = 'http://localhost:8081/api/flights';

  constructor(private http: HttpClient) {}

  /**
   * 🔍 Search for flights based on criteria
   */
  searchFlights(payload: FlightSearchRequest): Observable<FlightResponse[]> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });

    return this.http.post<FlightResponse[]>(`${this.baseUrl}/search`, payload, { headers });
  }

  /**
   * ✈️ Get flight by ID for booking
   */
  getFlightById(flightId: number): Observable<FlightResponse> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });

    return this.http.get<FlightResponse>(`${this.baseUrl}/${flightId}`, { headers });
  }

  getAllLocations(): Observable<string[]> {
  const token = localStorage.getItem('token');
  const headers = new HttpHeaders({ Authorization: `Bearer ${token}` });

  return this.http.get<string[]>('http://localhost:8081/api/flights/locations', { headers });
}

}
