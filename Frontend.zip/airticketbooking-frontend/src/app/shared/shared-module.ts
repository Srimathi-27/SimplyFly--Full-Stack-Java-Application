import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserNavbar } from './navbars/user-navbar/user-navbar';
import { AdminNavbar } from './navbars/admin-navbar/admin-navbar';
import { OwnerNavbar } from './navbars/owner-navbar/owner-navbar';
import { PublicNavbar } from './navbars/public-navbar/public-navbar';



@NgModule({
  declarations: [UserNavbar, AdminNavbar, OwnerNavbar, PublicNavbar],
  imports: [
    CommonModule
  ],
  exports: [UserNavbar,
    AdminNavbar,
    OwnerNavbar,
    PublicNavbar]
})
export class SharedModule { }
