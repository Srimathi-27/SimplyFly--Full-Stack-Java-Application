import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-landing',
  standalone: false,
  templateUrl: './landing.html',
  styleUrls: ['./landing.scss']
})
export class Landing implements OnInit, OnDestroy {
  slides = [
    {
      image: 'assets/images/slide1.jpg',
      title: 'Fly to Your Dream Destination',
      subtitle: 'Book your flight with exclusive offers'
    },
    {
      image: 'assets/images/slide2.jpg',
      title: 'Experience Seamless Travel',
      subtitle: 'Fast, easy, and secure bookings at your fingertips'
    },
    {
      image: 'assets/images/slide3.jpg',
      title: 'Discover the World with Us',
      subtitle: 'Uncover hidden gems with great deals'
    }
  ];

  currentSlide = 0;
  interval: any;

  ngOnInit(): void {
    this.startAutoSlide();
  }

  startAutoSlide() {
    this.interval = setInterval(() => {
      this.nextSlide();
    }, 5000); // ⏱️ 5 seconds per slide
  }

  nextSlide() {
    this.currentSlide = (this.currentSlide + 1) % this.slides.length;
  }

  prevSlide() {
    this.currentSlide =
      (this.currentSlide - 1 + this.slides.length) % this.slides.length;
  }

  ngOnDestroy(): void {
    clearInterval(this.interval);
  }
}
