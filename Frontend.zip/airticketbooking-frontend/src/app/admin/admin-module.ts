import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AdminRoutingModule } from './admin-routing-module';
import { Dashboard } from './dashboard/dashboard';
import { Flights } from './flights/flights';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Users } from './users/users';
import { FlightOwners } from './flight-owners/flight-owners';
import { Bookings } from './bookings/bookings';

import { Payments } from './payments/payments';
import { RoutesComponent } from './routes/routes';
import { FlightForm } from './flights/flight-form/flight-form';
import { Seats } from './seats/seats';



@NgModule({
  declarations: [
    Dashboard,
    Flights,
    Users,
    FlightOwners,
    Bookings,
    RoutesComponent,
    Payments,
    FlightForm,
    Seats,
    
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule,
    FormsModule
  ],
  providers: [DatePipe]
})
export class AdminModule { }
