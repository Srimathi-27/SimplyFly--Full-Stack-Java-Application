import { Component, OnInit } from '@angular/core';
import { Booking, BookingsService } from '../services/bookings.service';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-bookings',
  standalone: false,
  templateUrl: './bookings.html',
  styleUrl: './bookings.scss'
})
export class Bookings implements OnInit {
  bookings: Booking[] = [];
  isLoading = true;
  errorMessage = '';

  constructor(
    private bookingsService: BookingsService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadBookings();
  }

  loadBookings(): void {
    this.isLoading = true;
    this.bookingsService.getAllBookings().subscribe({
      next: (data) => {
        this.bookings = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to load bookings', err);
        this.alertService.error('❌ Failed to fetch bookings.');
        this.isLoading = false;
      }
    });
  }

  cancelBooking(id: number): void {
    this.alertService.confirm('Are you sure you want to cancel this booking?', 'Cancel Booking')
      .then((result) => {
        if (result.isConfirmed) {
          this.bookingsService.cancelBooking(id).subscribe({
            next: () => {
              this.alertService.success('✅ Booking cancelled.');
              this.loadBookings();
            },
            error: (err) => {
              console.error('Cancellation failed', err);
              this.alertService.error('❌ Failed to cancel booking.');
            }
          });
        }
      });
  }

  refundBooking(id: number): void {
  const booking = this.bookings.find(b => b.bookingId === id);

  if (!booking) {
    this.alertService.error('Booking not found.');
    return;
  }

  if (booking.status !== 'CANCELLED') {
    this.alertService.info('Only cancelled bookings can be refunded.');
    return;
  }

  if (booking.paymentStatus !== 'PAID') {
    this.alertService.info('Only paid bookings are eligible for refund.');
    return;
  }

  this.alertService.confirm('Do you want to refund this booking?', 'Refund Booking')
    .then((result) => {
      if (result.isConfirmed) {
        this.bookingsService.refund(id).subscribe({
          next: () => {
            this.alertService.success('✅ Refund successful.');
            this.loadBookings();
          },
          error: (err) => {
            console.error('Refund failed', err);
            this.alertService.error('❌ Refund failed.');
          }
        });
      }
    });
}

}
