import { Component, OnInit } from '@angular/core';
import { Payment, PaymentsService } from '../services/payments.service';

@Component({
  selector: 'app-payments',
  standalone: false,
  templateUrl: './payments.html',
  styleUrl: './payments.scss'
})
export class Payments implements OnInit{
  payments: Payment[] = [];
  isLoading = true;
  errorMessage = '';

  constructor(private paymentsService: PaymentsService) {}

  ngOnInit(): void {
    this.loadPayments();
  }

  loadPayments(): void {
    this.isLoading = true;
    this.paymentsService.getAllPayments().subscribe({
      next: (data) => {
        this.payments = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to load payments', err);
        this.errorMessage = 'Failed to fetch payments.';
        this.isLoading = false;
      }
    });
  }

}
