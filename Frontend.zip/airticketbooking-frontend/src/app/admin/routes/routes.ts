import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AlertService } from '../../shared/services/alert.service';

interface Route {
  id?: number;
  origin: string;
  destination: string;
  distanceInKm: number;
  duration: string;
}

@Component({
  selector: 'app-routes',
  standalone: false,
  templateUrl: './routes.html',
  styleUrls: ['./routes.scss']
})
export class RoutesComponent implements OnInit {
  routes: Route[] = [];
  route: Route = { origin: '', destination: '', distanceInKm: 0, duration: '' };
  editMode = false;
  showAddForm = false;
  selectedRouteId: number | null = null;

  token: string = localStorage.getItem('token') || '';

  constructor(private http: HttpClient, private alertService: AlertService) {}

  ngOnInit(): void {
    this.fetchRoutes();
  }

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`
    });
  }

  fetchRoutes(): void {
    this.http.get<Route[]>('http://localhost:8081/api/routes', {
      headers: this.getHeaders()
    }).subscribe({
      next: (data) => {
        this.routes = data;
      },
      error: (err) => console.error('Error fetching routes:', err)
    });
  }

  onSubmit(): void {
    const routePayload = {
      origin: this.route.origin,
      destination: this.route.destination,
      distanceInKm: this.route.distanceInKm,
      duration: this.route.duration
    };

    if (this.editMode && this.selectedRouteId !== null) {
      this.http.put(`http://localhost:8081/api/routes/${this.selectedRouteId}`, routePayload, {
        headers: this.getHeaders(),
        responseType: 'text' as 'json'  
      }).subscribe({
        next: () => {
          this.alertService.success('Route updated successfully ✅');
          this.fetchRoutes();
          this.cancelForm();
        },
        error: (err) => console.error('Error updating route:', err)
      });
    } else {
      this.http.post<Route>('http://localhost:8081/api/routes', routePayload, {
        headers: this.getHeaders()
      }).subscribe({
        next: (newRoute) => {
          this.alertService.success('Route added successfully ✅');
          this.routes.push(newRoute);
          this.cancelForm();
        },
        error: (err) => console.error('Error adding route:', err)
      });
    }
  }

  onEdit(route: Route): void {
    this.editMode = true;
    this.showAddForm = true;
    this.route = { ...route };
    this.selectedRouteId = route.id || null;
  }

  onDelete(route: Route): void {
  if (route.id && confirm('Are you sure you want to delete this route?')) {
    this.http.delete(`http://localhost:8081/api/routes/${route.id}`, {
      headers: this.getHeaders(),
      responseType: 'text' as 'json'
    }).subscribe({
      next: () => {
        this.alertService.success('Route deleted successfully ✅');
        this.fetchRoutes();
      },
      error: (err) => console.error('Error deleting route:', err)
    });
  }
}

  cancelForm(): void {
    this.route = { origin: '', destination: '', distanceInKm: 0, duration: '' };
    this.editMode = false;
    this.showAddForm = false;
    this.selectedRouteId = null;
  }

  openForm(): void {
    this.cancelForm();
    this.showAddForm = true;
  }
}
