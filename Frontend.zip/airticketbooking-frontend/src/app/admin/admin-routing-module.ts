import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { roleGuard } from '../shared/guards/role-guard';
import { Users } from './users/users';
import { FlightOwners } from './flight-owners/flight-owners';
import { Bookings } from './bookings/bookings';

import { Flights } from './flights/flights';
import { Payments } from './payments/payments';
import { RoutesComponent } from './routes/routes';
import { FlightForm } from './flights/flight-form/flight-form';
import { Seats } from './seats/seats';


const routes: Routes = [
  {
    path: '',
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_ADMIN' },
    children: [
      { path: 'dashboard', component: Dashboard },
      { path: 'users', component: Users },
      { path: 'flight-owners', component: FlightOwners },
      { path: 'bookings', component: Bookings },
      { path: 'routes', component: RoutesComponent },
      { path: 'flights', component: Flights },
      { path: 'payments', component: Payments },
      { path: 'flights/add', component: FlightForm },
      { path: 'flights/edit/:id', component: FlightForm },
      { path: 'seats/:flightId', component: Seats },


      // Default
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
