import { Component, OnInit } from '@angular/core';
import { FlightOwner, OwnersService } from '../services/owners.service';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-flight-owners',
  standalone: false,
  templateUrl: './flight-owners.html',
  styleUrl: './flight-owners.scss'
})
export class FlightOwners implements OnInit {
  flightOwners: FlightOwner[] = [];
  isLoading = true;
  errorMessage = '';

  constructor(
    private ownersService: OwnersService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadOwners();
  }

  loadOwners(): void {
    this.isLoading = true;
    this.ownersService.getFlightOwners().subscribe({
      next: (data) => {
        this.flightOwners = data.filter(
          owner => owner.role?.toUpperCase() === 'FLIGHT_OWNER'
        );
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching flight owners', err);
        this.alertService.error('❌ Failed to load flight owners');
        this.isLoading = false;
      }
    });
  }

  deleteOwner(id: number): void {
    this.alertService.confirm('Are you sure you want to delete this flight owner?', 'Delete Owner')
      .then((result) => {
        if (result.isConfirmed) {
          this.ownersService.deleteFlightOwner(id).subscribe({
            next: () => {
              this.alertService.success('✅ Flight owner deleted successfully.');
              this.loadOwners();
            },
            error: (err) => {
              console.error('Delete flight owner failed', err);
              this.alertService.error('❌ Failed to delete flight owner.');
            }
          });
        }
      });
  }
}
