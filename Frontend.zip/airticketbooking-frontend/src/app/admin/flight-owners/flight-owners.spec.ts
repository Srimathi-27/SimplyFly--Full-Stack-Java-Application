import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightOwners } from './flight-owners';

describe('FlightOwners', () => {
  let component: FlightOwners;
  let fixture: ComponentFixture<FlightOwners>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FlightOwners]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FlightOwners);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
