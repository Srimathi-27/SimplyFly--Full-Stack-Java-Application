import { Component, OnInit } from '@angular/core';
import { Flight, FlightsAdminService } from '../services/flights-admin.service';
import { Router } from '@angular/router';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-flights',
  standalone: false,
  templateUrl: './flights.html',
  styleUrls: ['./flights.scss']
})
export class Flights implements OnInit {
  flights: Flight[] = [];
  isLoading = true;
  errorMessage = '';

  constructor(
    private flightsService: FlightsAdminService,
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.fetchFlights();
  }

  fetchFlights(): void {
    this.flightsService.getAllFlights().subscribe({
      next: (data) => {
        this.flights = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to load flights', err);
        this.alertService.error('❌ Unable to fetch flights.');
        this.isLoading = false;
      }
    });
  }

  deleteFlight(id: number): void {
    this.alertService.confirm('This will permanently delete the flight. Continue?', 'Delete Flight')
      .then((result) => {
        if (result.isConfirmed) {
          this.flightsService.deleteFlight(id).subscribe({
            next: () => {
              this.alertService.success('✅ Flight deleted successfully!');
              this.fetchFlights();
            },
            error: () => {
              this.alertService.error('❌ Failed to delete flight.');
            }
          });
        }
      });
  }

  addFlight(): void {
    this.router.navigate(['/admin/flights/add']);
  }

  editFlight(id: number): void {
    this.router.navigate(['/admin/flights/edit', id]);
  }

  viewSeats(flightId: number): void {
    this.router.navigate(['/admin/seats', flightId]);
  }
}
