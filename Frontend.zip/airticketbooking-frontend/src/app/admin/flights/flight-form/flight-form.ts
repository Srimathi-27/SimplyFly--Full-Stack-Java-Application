import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  AdminService,
  Flight,
  AddFlightRequest,
  Route
} from '../../../shared/services/admin.service';
import { AlertService } from '../../../shared/services/alert.service';

@Component({
  selector: 'app-flight-form',
  standalone: false,
  templateUrl: './flight-form.html',
  styleUrls: ['./flight-form.scss']
})
export class FlightForm implements OnInit {
  flightForm!: FormGroup;
  routes: Route[] = [];
  isEditMode = false;
  isSubmitting = false;
  errorMessage = '';
  flightId!: number;

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.loadRoutes();
  }

  initializeForm(): void {
    this.flightForm = this.fb.group({
      flightNumber: ['', Validators.required],
      flightName: ['', Validators.required],
      routeId: ['', Validators.required],
      fare: [null, [Validators.required, Validators.min(1)]],
      totalSeats: [null, [Validators.required, Validators.min(1)]],
      baggageCheckin: ['', Validators.required],
      baggageCabin: ['', Validators.required],
      departureTime: ['', Validators.required],
      arrivalTime: ['', Validators.required]
    });
  }

  loadRoutes(): void {
    this.adminService.getAllRoutes().subscribe({
      next: (routes) => {
        this.routes = routes;

        const idParam = this.route.snapshot.paramMap.get('id');
        if (idParam) {
          this.flightId = +idParam;
          this.isEditMode = true;
          this.loadFlight(this.flightId);
        }
      },
      error: () => {
        this.errorMessage = '❌ Could not fetch route list.';
      }
    });
  }

  loadFlight(id: number): void {
    this.adminService.getFlightById(id).subscribe({
      next: (flight: Flight) => {
        const matchedRoute = this.routes.find(r => r.id === flight.routeId);
        if (!matchedRoute) {
          this.errorMessage = `❌ No matching route found for ID ${flight.routeId} (${flight.origin} → ${flight.destination})`;
          this.flightForm.disable();
          return;
        }

        this.flightForm.patchValue({
          flightNumber: flight.flightNumber,
          flightName: flight.flightName,
          routeId: flight.routeId.toString(),
          fare: flight.fare,
          totalSeats: flight.totalSeats,
          baggageCheckin: flight.baggageCheckin,
          baggageCabin: flight.baggageCabin,
          departureTime: this.formatDateTime(flight.departureTime),
          arrivalTime: this.formatDateTime(flight.arrivalTime)
        });
      },
      error: () => {
        this.errorMessage = '❌ Failed to load flight details.';
      }
    });
  }

  formatDateTime(datetime: string): string {
    return datetime ? datetime.slice(0, 16) : '';
  }

  submit(): void {
  if (this.flightForm.invalid) return;

  this.isSubmitting = true;
  this.errorMessage = '';

  const raw = this.flightForm.value;
  const routeId = parseInt(raw.routeId, 10);

  if (isNaN(routeId) || routeId <= 0) {
    this.alertService.error('Invalid Route selected. Please choose again.');
    this.isSubmitting = false;
    return;
  }

  const payload: AddFlightRequest = {
    ...raw,
    routeId,
    departureTime: new Date(raw.departureTime).toISOString(),
    arrivalTime: new Date(raw.arrivalTime).toISOString()
  };

  const request = this.isEditMode
    ? this.adminService.updateFlight(this.flightId, payload)
    : this.adminService.addFlight(payload);

  request.subscribe({
    next: () => {
      const message = this.isEditMode
        ? '✈️ Flight updated successfully!'
        : '✅ Flight added successfully!';
      this.alertService.success(message).then(() => {
        this.router.navigate(['/admin/flights']);
      });
    },
    error: () => {
      this.alertService.error(
        this.isEditMode
          ? '❌ Failed to update flight.'
          : '❌ Failed to create flight.'
      );
      this.isSubmitting = false;
    }
  });
}

}
