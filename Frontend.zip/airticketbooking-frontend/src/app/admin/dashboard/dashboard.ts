import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../shared/services/admin.service';

type StatKey = 'users' | 'flightOwners' | 'bookings' | 'flights' | 'payments' | 'routes';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss']
})
export class Dashboard implements OnInit {

  // State variables
  isLoading = true;
  errorMessage = '';

  // Raw stats from API
  stats: Record<StatKey, number> = {
    users: 0,
    flightOwners: 0,
    bookings: 0,
    flights: 0,
    payments: 0,
    routes: 0
  };

  // Animated values for display
  animatedStats: Record<StatKey, number> = {
    users: 0,
    flightOwners: 0,
    bookings: 0,
    flights: 0,
    payments: 0,
    routes: 0
  };

  // Dashboard card configuration
  statList: { label: string; key: StatKey; class: string; icon: string }[] = [
    { label: 'Users', key: 'users', class: 'users', icon: 'bi bi-people' },
    { label: 'Flight Owners', key: 'flightOwners', class: 'owners', icon: 'bi bi-person-badge' },
    { label: 'Bookings', key: 'bookings', class: 'bookings', icon: 'bi bi-journal-check' },
    { label: 'Flights', key: 'flights', class: 'flights', icon: 'bi bi-airplane-engines' },
    { label: 'Routes', key: 'routes', class: 'routes', icon: 'bi bi-geo-alt' },
    { label: 'Payments', key: 'payments', class: 'payments', icon: 'bi bi-credit-card' }
  ];

  constructor(private adminService: AdminService) {}


  ngOnInit(): void {
    this.fetchDashboardStats();
  }

  fetchDashboardStats(): void {
    this.adminService.getDashboardStats().subscribe({
      next: (data) => {
        this.stats = data;
        this.animateNumbers(data);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching dashboard stats', err);
        this.errorMessage = 'Failed to load dashboard data.';
        this.isLoading = false;
      }
    });
  }

  animateNumbers(targetStats: Record<StatKey, number>) {
    if (!targetStats) return;

    const duration = 1000; // milliseconds
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      (Object.entries(targetStats) as [StatKey, number][]).forEach(([key, value]) => {
        this.animatedStats[key] = Math.floor(progress * value);
      });

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }
}
