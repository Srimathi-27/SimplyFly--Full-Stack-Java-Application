import { TestBed } from '@angular/core/testing';

import { Owners } from './owners';

describe('Owners', () => {
  let service: Owners;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Owners);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
