import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface FlightOwner {
  id: number;
  name: string;
  email: string;
  gender: string;
  phone: string;
  address: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class OwnersService {
  private baseUrl = 'http://localhost:8081/api/users';

  constructor(private http: HttpClient) {}

  getFlightOwners(): Observable<FlightOwner[]> {
    return this.http.get<FlightOwner[]>(this.baseUrl);
  }

  deleteFlightOwner(id: number): Observable<any> {
  return this.http.delete(`${this.baseUrl}/${id}`);
}


}
