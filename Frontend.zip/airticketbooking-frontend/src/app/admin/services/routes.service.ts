import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Route {
  id?: number; // We'll manage this manually since AddRouteRequest has no id
  origin: string;
  destination: string;
  distanceInKm: number;
  duration: string;
}

@Injectable({
  providedIn: 'root'
})
export class RoutesService {
  private baseUrl = 'http://localhost:8081/api/routes';

  constructor(private http: HttpClient) {}

  // 🔍 Get all routes
  getAllRoutes(): Observable<Route[]> {
    return this.http.get<Route[]>(this.baseUrl);
  }

  // ➕ Add new route
  addRoute(route: Route): Observable<string> {
    return this.http.post(this.baseUrl, route, { responseType: 'text' });
  }

  // ✏️ Update route by ID
  updateRoute(id: number, route: Route): Observable<string> {
    return this.http.put(`${this.baseUrl}/${id}`, route, { responseType: 'text' });
  }

  // 🗑️ Delete route by ID
  deleteRoute(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }
}
