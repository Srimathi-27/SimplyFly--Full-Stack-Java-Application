import { TestBed } from '@angular/core/testing';

import { FlightsAdmin } from './flights-admin';

describe('FlightsAdmin', () => {
  let service: FlightsAdmin;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FlightsAdmin);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
