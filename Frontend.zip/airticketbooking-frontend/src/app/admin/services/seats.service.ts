import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Seat {
  id: number;
  seatNumber: string;
  booked: boolean;
  seatClass: 'ECONOMY' | 'BUSINESS';
}

@Injectable({ providedIn: 'root' })
export class SeatService {
  private baseUrl = 'http://localhost:8081/api/seats';

  constructor(private http: HttpClient) {}

  getGroupedSeats(flightId: number, onlyAvailable = false): Observable<Record<string, Seat[]>> {
    return this.http.get<Record<string, Seat[]>>(
      `${this.baseUrl}/flight/${flightId}/grouped?onlyAvailable=${onlyAvailable}`
    );
  }

  getAllSeats(flightId: number): Observable<Seat[]> {
    return this.http.get<Seat[]>(`${this.baseUrl}/flight/${flightId}/all`);
  }

  getAvailableSeats(flightId: number): Observable<Seat[]> {
    return this.http.get<Seat[]>(`${this.baseUrl}/flight/${flightId}/available`);
  }
}
