import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Booking {
  bookingId: number;
  flightNumber: string;
  flightName: string;
  origin: string;
  destination: string;
  seatCount: number;
  totalPrice: number;
  status: string;
  bookingDate: string;
  bookedSeatNumbers: string[];
  paymentStatus: string;
}

@Injectable({
  providedIn: 'root'
})
export class BookingsService {
  private baseUrl = 'http://localhost:8081/api/bookings';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  // ✅ Get all bookings (admin)
  getAllBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.baseUrl}/all`, {
      headers: this.getHeaders()
    });
  }

  // ❌ Cancel booking (admin)
  cancelBooking(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/${id}`, {
      headers: this.getHeaders(),
      responseType: 'text'
    });
  }

  // 💸 Refund booking (admin)
  refund(bookingId: number): Observable<string> {
    return this.http.post(`http://localhost:8081/api/payments/refund/${bookingId}`, {}, {
      headers: this.getHeaders(),
      responseType: 'text'
    });
  }
}
