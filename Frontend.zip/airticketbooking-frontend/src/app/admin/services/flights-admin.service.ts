// src/app/admin/services/flights-admin.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Flight {
  id: number;
  flightNumber: string;
  flightName: string;
  routeId: number;
  fare: number;
  totalSeats: number;
  baggageCheckin: string;
  baggageCabin: string;
  departureTime: string;
  arrivalTime: string;
  origin?: string;
  destination?: string;
  flightOwnerEmail?: string;
}

@Injectable({
  providedIn: 'root'
})
export class FlightsAdminService {
  private baseUrl = 'http://localhost:8081/api/flights'; // adjust if deployed

  constructor(private http: HttpClient) {}

  getAllFlights(): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.baseUrl}`);
  }

  getFlightById(id: number): Observable<Flight> {
    return this.http.get<Flight>(`${this.baseUrl}/${id}`);
  }

  addFlight(flight: Flight): Observable<string> {
    return this.http.post(`${this.baseUrl}`, flight, { responseType: 'text' });
  }

  updateFlight(id: number, flight: Flight): Observable<string> {
    return this.http.put(`${this.baseUrl}/${id}`, flight, { responseType: 'text' });
  }

  deleteFlight(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }
}

