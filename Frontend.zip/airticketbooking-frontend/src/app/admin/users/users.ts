import { Component, OnInit } from '@angular/core';
import { AdminService, User } from '../../shared/services/admin.service';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-users',
  standalone: false,
  templateUrl: './users.html',
  styleUrl: './users.scss'
})
export class Users implements OnInit {
  users: User[] = [];
  isLoading = true;

  constructor(
    private adminService: AdminService,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.isLoading = true;
    this.adminService.getAllUsers().subscribe({
      next: (data) => {
        this.users = data;
        this.isLoading = false;
      },
      error: () => {
        this.alertService.error('❌ Failed to fetch users.');
        this.isLoading = false;
      }
    });
  }

  deleteUser(id: number): void {
    this.alertService.confirm('Are you sure you want to delete this user?', 'Delete User')
      .then((result) => {
        if (result.isConfirmed) {
          this.adminService.deleteUser(id).subscribe({
            next: () => {
              this.alertService.success('✅ User deleted successfully.');
              this.loadUsers();
            },
            error: () => {
              this.alertService.error('❌ Failed to delete user.');
            }
          });
        }
      });
  }
}
