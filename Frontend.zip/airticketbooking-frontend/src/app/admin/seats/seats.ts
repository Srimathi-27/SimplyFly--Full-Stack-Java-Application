import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Seat, SeatService } from '../services/seats.service';

@Component({
  selector: 'app-seats',
  standalone: false,
  templateUrl: './seats.html',
  styleUrl: './seats.scss'
})
export class Seats implements OnInit {
  groupedSeats: Record<string, Seat[]> = {};
  allSeats: Seat[] = [];
  isLoading = true;
  errorMessage = '';
  flightId: number = 0;
  Object = Object; // Needed to use Object.keys() in template

  constructor(private route: ActivatedRoute, private seatService: SeatService) {}

  ngOnInit(): void {
    this.flightId = +this.route.snapshot.paramMap.get('flightId')!;
    this.loadSeats();
  }

  loadSeats(): void {
    this.seatService.getGroupedSeats(this.flightId).subscribe({
      next: (grouped) => {
        this.groupedSeats = grouped;

        this.seatService.getAllSeats(this.flightId).subscribe({
          next: (all) => {
            this.allSeats = all;
            this.isLoading = false;
          },
          error: (err) => {
            console.error('Error loading all seats:', err);
            this.errorMessage = 'Failed to load seat details.';
            this.isLoading = false;
          }
        });
      },
      error: (err) => {
        console.error('Error loading grouped seats:', err);
        this.errorMessage = 'Failed to load seat layout.';
        this.isLoading = false;
      }
    });
  }

  isBooked(seatNumber: string): boolean {
    const seat = this.allSeats.find(s => s.seatNumber === seatNumber);
    return seat ? seat.booked : false;
  }

  getSeatClass(seatNumber: string): 'ECONOMY' | 'BUSINESS' {
    const seat = this.allSeats.find(s => s.seatNumber === seatNumber);
    return seat ? seat.seatClass : 'ECONOMY'; // fallback default
  }
}
