import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FlightService } from '../../shared/services/flight';
import { SeatService } from '../../shared/services/seat';
import { FlightResponse } from '../../shared/models/flight-model';
import { SeatDTO } from '../../shared/models/seat-model';

@Component({
  selector: 'app-book-flight',
  standalone: false,
  templateUrl: './book-flight.html',
  styleUrls: ['./book-flight.scss']
})
export class BookFlight implements OnInit {
  flightId!: number;
  flight?: FlightResponse;

  seatCount: number = 1;
  groupedSeats: Record<string, SeatDTO[]> = {};
  selectedSeats: string[] = [];

  bookingError: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private flightService: FlightService,
    private seatService: SeatService
  ) {}

  ngOnInit(): void {
    this.flightId = Number(this.route.snapshot.paramMap.get('id'));
    if (this.flightId) {
      this.loadFlightDetails();
      this.loadGroupedSeats();
    } else {
      this.router.navigate(['/user/flights/search']);
    }
  }

  private loadFlightDetails(): void {
    this.flightService.getFlightById(this.flightId).subscribe({
      next: (data) => this.flight = data,
      error: (err) => {
        console.error('❌ Failed to load flight details:', err);
        this.router.navigate(['/user/flights/search']);
      }
    });
  }

  private loadGroupedSeats(): void {
    this.seatService.getGroupedSeats(this.flightId).subscribe({
      next: (data) => {
        this.groupedSeats = data;
        console.log('✅ Grouped seats:', data);
      },
      error: (err) => {
        console.error('❌ Failed to load seats:', err);
      }
    });
  }

  get seatRowKeys(): string[] {
    return Object.keys(this.groupedSeats)
      .filter(row => this.groupedSeats[row]?.length > 0)
      .sort((a, b) => Number(a) - Number(b));
  }

  getLeftSeats(rowKey: string): SeatDTO[] {
    return (this.groupedSeats[rowKey] || []).filter(seat =>
      ['A', 'B', 'C'].includes(seat.seatNumber.slice(-1))
    );
  }

  getRightSeats(rowKey: string): SeatDTO[] {
    return (this.groupedSeats[rowKey] || []).filter(seat =>
      ['D', 'E', 'F'].includes(seat.seatNumber.slice(-1))
    );
  }

  toggleSeat(seat: SeatDTO): void {
  if (seat.booked || seat.status === 'BLOCKED') {
    this.bookingError = `Seat ${seat.seatNumber} is not available.`;
    return;
  }

  const alreadySelected = this.selectedSeats.includes(seat.seatNumber);

  if (alreadySelected) {
    this.selectedSeats = this.selectedSeats.filter(s => s !== seat.seatNumber);
  } else {
    if (this.selectedSeats.length >= this.seatCount) {
      this.bookingError = `You can select up to ${this.seatCount} seat(s).`;
      return;
    }
    this.selectedSeats.push(seat.seatNumber);
  }

  this.bookingError = '';
}


  reviewBooking(): void {
    this.bookingError = '';

    if (!this.flight) {
      this.bookingError = 'Flight details not available.';
      return;
    }

    if (this.seatCount <= 0) {
      this.bookingError = 'Please select at least 1 seat.';
      return;
    }

    if (this.selectedSeats.length !== this.seatCount) {
      this.bookingError = `Please select exactly ${this.seatCount} seat(s).`;
      return;
    }

    const allSeats: SeatDTO[] = Object.values(this.groupedSeats).flat();

    this.router.navigate(['/user/booking-summary'], {
      state: {
        flight: this.flight,
        seatCount: this.seatCount,
        selectedSeats: this.selectedSeats,
        allSeats: allSeats // For dynamic fare calculation in summary
      }
    });
  }

  getSeatClasses(seat: SeatDTO): string[] {
  const isSelected = this.selectedSeats.includes(seat.seatNumber);

  if (seat.status === 'BLOCKED') return ['seat', 'blocked']; // 👈 blocked first
  if (seat.booked) return ['seat', 'booked'];
  if (isSelected) return ['seat', 'selected'];
  if (seat.seatClass === 'ECONOMY') return ['seat', 'economy'];
  if (seat.seatClass === 'BUSINESS') return ['seat', 'business'];
  return ['seat'];
}


  get totalFare(): number {
    if (!this.flight || !this.selectedSeats.length) return 0;

    const economyFare = this.flight.fare;
    const businessFare = this.flight.fare * 1.5;

    const allSeats: SeatDTO[] = Object.values(this.groupedSeats).flat();

    return this.selectedSeats.reduce((sum, seatNum) => {
      const seat = allSeats.find(s => s.seatNumber === seatNum);
      return seat ? sum + (seat.seatClass === 'BUSINESS' ? businessFare : economyFare) : sum;
    }, 0);
  }
}
