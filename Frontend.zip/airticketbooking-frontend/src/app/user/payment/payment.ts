import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightResponse } from '../../shared/models/flight-model';
import { PaymentService } from '../../shared/services/payment';
import { PaymentRequest } from '../../shared/models/payment-model';
import { SeatDTO } from '../../shared/models/seat-model';

@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.html',
  styleUrls: ['./payment.scss']
})
export class Payment implements OnInit {
  bookingId!: number;
  flight!: FlightResponse;
  selectedSeats: string[] = [];
  allSeats: SeatDTO[] = [];
  totalFare: number = 0;

  selectedMethod: string = 'CARD'; // 🆕 Default method

  isPaying: boolean = false;
  error: string = '';
  success: boolean = false;

  constructor(
    private paymentService: PaymentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const state = history.state;

    if (!state || !state.bookingId || !state.flight || !state.selectedSeats || !state.allSeats) {
      this.router.navigate(['/user/dashboard']);
      return;
    }

    this.bookingId = state.bookingId;
    this.flight = state.flight;
    this.selectedSeats = state.selectedSeats;
    this.allSeats = state.allSeats;
    this.totalFare = this.calculateTotalFare();
  }

  /**
   * 💰 Calculates total fare based on seat class
   */
  calculateTotalFare(): number {
    const baseFare = this.flight.fare;
    const businessFare = baseFare * 1.5;

    return this.selectedSeats.reduce((sum, seatNum) => {
      const seat = this.allSeats.find(s => s.seatNumber === seatNum);
      if (!seat) return sum;
      return sum + (seat.seatClass === 'BUSINESS' ? businessFare : baseFare);
    }, 0);
  }

  /**
   * 💸 Trigger payment request with selected method
   */
  confirmAndPay(): void {
    if (!this.selectedMethod) {
      this.error = 'Please select a payment method.';
      return;
    }

    const request: PaymentRequest = {
      bookingId: this.bookingId,
      paymentMethod: this.selectedMethod
    };

    this.isPaying = true;
    this.error = '';
    this.success = false;

    this.paymentService.makePayment(request).subscribe({
      next: () => {
        this.success = true;
        this.isPaying = false;

        setTimeout(() => {
          this.router.navigate(['/user/bookings']);
        }, 5000);
      },
      error: (err) => {
        console.error('❌ Payment failed:', err);
        this.error = 'Payment failed. Please try again.';
        this.isPaying = false;
      }
    });
  }

  retry(): void {
    this.confirmAndPay();
  }
}
