import { Component, OnInit } from '@angular/core';
import { BookingService } from '../../shared/services/booking';
import { BookingResponse } from '../../shared/models/booking-model';

@Component({
  selector: 'app-my-booking',
  standalone: false,
  templateUrl: './my-booking.html',
  styleUrl: './my-booking.scss'
})
export class MyBooking implements OnInit {
  bookings: BookingResponse[] = [];
  filteredBookings: BookingResponse[] = [];
  paginatedBookings: BookingResponse[] = [];

  selectedStatus: string = 'ALL';

  loading = true;
  error: string = '';

  currentPage = 1;
  pageSize = 5;
  totalPages = 1;

  constructor(private bookingService: BookingService) {}

  ngOnInit(): void {
    this.fetchBookings();
  }

  private fetchBookings(): void {
    this.bookingService.getUserBookings().subscribe({
      next: (data) => {
        this.bookings = data;
        this.applyFilters();
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to fetch bookings:', err);
        this.error = 'Failed to load booking history.';
        this.loading = false;
      }
    });
  }

  /**
   * Filter bookings by selected status
   */
  filterBookings(): void {
    this.currentPage = 1;
    this.applyFilters();
  }

  private applyFilters(): void {
    if (this.selectedStatus === 'ALL') {
      this.filteredBookings = [...this.bookings];
    } else {
      this.filteredBookings = this.bookings.filter(b => b.status === this.selectedStatus);
    }
    this.totalPages = Math.ceil(this.filteredBookings.length / this.pageSize);
    this.paginateBookings();
  }

  /**
   * Slice data for current page
   */
  paginateBookings(): void {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedBookings = this.filteredBookings.slice(start, end);
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.paginateBookings();
    }
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.paginateBookings();
    }
  }

  cancelBooking(id: number): void {
    if (!confirm('Are you sure you want to cancel this booking?')) return;

    this.bookingService.cancelBooking(id).subscribe({
      next: () => {
        this.bookings = this.bookings.map(b =>
          b.bookingId === id ? { ...b, status: 'CANCELLED' } : b
        );
        this.applyFilters();
        alert('✅ Booking cancelled successfully.');
      },
      error: (err) => {
        console.error('Cancel failed:', err);
        alert('❌ Failed to cancel booking.');
      }
    });
  }

  hasAnyBooked(): boolean {
    return this.bookings?.some(b => b.status === 'BOOKED');
  }
}
