import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FlightResponse } from '../../shared/models/flight-model';
import { FlightService } from '../../shared/services/flight';
import { map, Observable, startWith } from 'rxjs';

@Component({
  selector: 'app-search-flight',
  standalone: false,
  templateUrl: './search-flight.html',
  styleUrl: './search-flight.scss'
})
export class SearchFlight implements OnInit{
  form: FormGroup;
  flights: FlightResponse[] = [];
  today: string = new Date().toISOString().split('T')[0];

  locations: string[] = [];
  filteredOrigins!: Observable<string[]>;
  filteredDestinations!: Observable<string[]>;

  constructor(
    private fb: FormBuilder,
    private flightService: FlightService,
    private router: Router
  ) {
    this.form = this.fb.group({
      origin: ['', Validators.required],
      destination: ['', Validators.required],
      departureDate: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.flightService.getAllLocations().subscribe({
      next: (data) => {
        this.locations = data;
        this.setupAutocomplete();
      },
      error: (err) => console.error('❌ Failed to load locations:', err)
    });
  }

  setupAutocomplete(): void {
    this.filteredOrigins = this.form.get('origin')!.valueChanges.pipe(
      startWith(''),
      map(value => this.filterLocation(value))
    );

    this.filteredDestinations = this.form.get('destination')!.valueChanges.pipe(
      startWith(''),
      map(value => this.filterLocation(value))
    );
  }

  filterLocation(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.locations.filter(loc => loc.toLowerCase().includes(filterValue));
  }

  onSearch(): void {
    if (this.form.valid) {
      this.flightService.searchFlights(this.form.value).subscribe({
        next: (data) => {
          this.flights = data;
        },
        error: (err) => {
          console.error('❌ Flight search failed:', err);
        }
      });
    }
  }

  bookFlight(flight: FlightResponse): void {
    this.router.navigate(['/user/book', flight.id]);
  }

  goToDashboard(): void {
  this.router.navigate(['/user/dashboard']);
}

}
