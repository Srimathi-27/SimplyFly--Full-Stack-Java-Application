import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../shared/services/user';

// ✅ Optional: Interface for better type safety
interface User {
  name: string;
  email: string;
}

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard implements OnInit {
  username: string = '';
  email: string = '';

  constructor(
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadUserProfile();
  }

  /**
   * 🔄 Loads the currently logged-in user's profile from the backend
   */
  private loadUserProfile(): void {
    this.userService.getCurrentUser().subscribe({
      next: (user: User) => {
        console.log('✅ User profile loaded:', user);
        this.username = user.name || 'Guest';
        this.email = user.email || '';
      },
      error: (err) => {
        console.error('❌ Failed to load user profile:', err);
      }
    });
  }

  // ✅ Button navigation methods
  goToSearch(): void {
    this.router.navigate(['/user/flights/search']);
  }

  goToBookings(): void {
    this.router.navigate(['/user/bookings']);
  }

  goToProfile(): void {
    this.router.navigate(['/user/profile']);
  }
  

}
