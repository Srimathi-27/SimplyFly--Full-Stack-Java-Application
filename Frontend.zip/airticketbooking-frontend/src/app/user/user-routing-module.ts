import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Dashboard } from '../user/dashboard/dashboard';
import { roleGuard } from '../shared/guards/role-guard';
import { SearchFlight } from './search-flight/search-flight';
import { UserProfile } from './user-profile/user-profile';
import { MyBooking } from './my-booking/my-booking';
import { BookFlight } from './book-flight/book-flight';
import { BookingSummary } from './booking-summary/booking-summary';
import { Payment } from './payment/payment';

const routes: Routes = [
  {
    path: 'dashboard',
    component: Dashboard,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'flights/search',
    component: SearchFlight,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'user/book-flight',
    component: BookFlight,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'book/:id', 
    component: BookFlight,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'booking-summary',
    component: BookingSummary,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'payment',
    component: Payment,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'bookings',
    component: MyBooking,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  },
  {
    path: 'profile',
    component: UserProfile,
    canActivate: [roleGuard],
    data: { expectedRole: 'ROLE_USER' }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
