import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightResponse } from '../../shared/models/flight-model';
import { SeatDTO } from '../../shared/models/seat-model';
import { BookingService } from '../../shared/services/booking';
import { BookingRequest, BookingResponse } from '../../shared/models/booking-model';

@Component({
  selector: 'app-booking-summary',
  standalone: false,
  templateUrl: './booking-summary.html',
  styleUrl: './booking-summary.scss'
})
export class BookingSummary implements OnInit {
  flight!: FlightResponse;
  selectedSeats: string[] = [];
  allSeats: SeatDTO[] = [];
  seatCount: number = 0;
  totalFare: number = 0;

  isBooking = false;
  error = '';

  constructor(
    private router: Router,
    private bookingService: BookingService
  ) {}

  ngOnInit(): void {
    const state = history.state;

    if (!state || !state.flight || !state.allSeats || !state.selectedSeats) {
      this.router.navigate(['/user/dashboard']);
      return;
    }

    this.flight = state.flight;
    this.selectedSeats = state.selectedSeats;
    this.allSeats = state.allSeats;
    this.seatCount = this.selectedSeats.length;
    this.totalFare = this.calculateTotalFare();
  }

  /**
   * 💰 Calculates total fare based on selected seat classes
   */
  private calculateTotalFare(): number {
    const economyFare = this.flight.fare;
    const businessFare = this.flight.fare * 1.5;

    return this.selectedSeats.reduce((sum, seatNumber) => {
      const seat = this.allSeats.find(s => s.seatNumber === seatNumber);
      if (!seat) return sum;
      return sum + (seat.seatClass === 'BUSINESS' ? businessFare : economyFare);
    }, 0);
  }

  /**
   * 📦 Submits booking and navigates to payment page
   */
  proceedToPayment(): void {
    this.isBooking = true;

    const request: BookingRequest = {
      flightId: this.flight.id,
      seatCount: this.seatCount,
      seatNumbers: this.selectedSeats
    };

    this.bookingService.bookFlight(request).subscribe({
      next: (booking: BookingResponse) => {
        this.router.navigate(['/user/payment'], {
          state: {
            bookingId: booking.bookingId,
            totalFare: this.totalFare,
            flight: this.flight,
            selectedSeats: this.selectedSeats,
            allSeats: this.allSeats
          }
        });
      },
      error: (err) => {
        console.error('❌ Booking failed:', err);
        this.error = 'Failed to book flight. Please try again.';
        this.isBooking = false;
      }
    });
  }
}
