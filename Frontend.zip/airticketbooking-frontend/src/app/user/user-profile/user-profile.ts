import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/services/user';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-user-profile',
  standalone: false,
  templateUrl: './user-profile.html',
  styleUrl: './user-profile.scss'
})
export class UserProfile implements OnInit {
  form!: FormGroup;
  loading = true;
  successMessage = '';
  errorMessage = '';
  editMode = false;
  passwordForm!: FormGroup;
showPasswordSection = false;


  constructor(private fb: FormBuilder, private userService: UserService, private alertService: AlertService) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: [{ value: '', disabled: true }],
      contactNumber: ['', [Validators.pattern(/^[6-9]\d{9}$/)]],
      gender: ['']
    });

    this.userService.getCurrentUser().subscribe({
      next: (user) => {
        user.contactNumber = user.phone; 
        this.form.patchValue(user);
        this.loading = false;
      },
      error: () => {
        this.errorMessage = '❌ Failed to load profile';
        this.loading = false;
      }
    });
    this.passwordForm = this.fb.group({
  currentPassword: ['', Validators.required],
  newPassword: ['', [Validators.required, Validators.minLength(6)]]
});

  }

  onSubmit(): void {
  if (this.form.invalid) return;

  this.userService.updateUserProfile(this.form.getRawValue()).subscribe({
    next: () => {
      this.alertService.toast('✅ Profile updated successfully!', 'success');
      this.editMode = false;
    },
    error: () => {
      this.alertService.toast('❌ Update failed. Please try again.', 'error');
    }
  });
}


  cancelEdit(): void {
    this.editMode = false;
    this.successMessage = '';
    this.errorMessage = '';
  }
  changePassword(): void {
  if (this.passwordForm.invalid) return;

  this.userService.changePassword(this.passwordForm.value).subscribe({
    next: () => {
      this.alertService.toast('✅ Password updated successfully!', 'success');
      this.passwordForm.reset();
      this.showPasswordSection = false;
    },
    error: (err) => {
      this.alertService.toast('❌ Failed to update password.', 'error');
      console.error(err);
    }
  });
}

}
